title: Cage Twins cage weapons: heal-or-weapon choice for winner
result: inconclusive
phase: done
updated: 22:55:29 (+30m)

[22:25:13 +00m] started - source branch master, task: redesign Cage Twins cage weapons - winner picks heal or random weapon between rounds; heals restore missing arms
[22:28:01 +02m] oriented - multiplayer: card says Cage Twins + Rumble repair kits, code is CageItemSpawner/CageController/GenericMechPickupper (MP); job feature: new design replacing the between-round heal
[22:29:15 +04m] editor - unity_ready: ready, no compile errors, safe_mode_ignored false
[22:31:48 +06m] criteria - (1) Cage Twins: after a win, a health option and a random weapon option (Niv's list) spawn at two fixed points in the winner's cage; (2) no automatic heal on win in Cage Twins, the health option gives today's heal amount; (3) taking one removes the other; (4) an untaken option disappears when the cage reopens (Closed -> Open/Empty); (5) new pair each round; (6) a taken weapon is not destroyed when someone enters / a fight starts; (7) second weapon can be taken with the free hand; (8) a dropped weapon on death despawns after 10 s; (9) the pad timer ring shows time left before the options disappear; (10) heals restore a missing arm, incl. Rumble repair kits (revert 975b1d48e4)
[22:31:48 +06m] decision - health amount: the option calls CageController's existing survivor heal (healAmountCurve by streak, same snapshot logic), because the card says "same amount as today's heal"
[22:31:48 +06m] decision - fixed locations: CageItemSpawner.locations[0] = weapon option, [1] = health option (existing scene points, no new transforms), because the card asks for two fixed points and the points already exist
[22:31:48 +06m] decision - health option object: a new spawnOnRequest Respawnable pad per cage spawning the existing Cage Health Reward prefab, because it is the existing networked cage health pickup
[22:31:48 +06m] decision - Red Cage keeps the automatic heal: only a cage with a CageItemSpawner turns it off (CageController.SetSurvivorHealOnPickup), because the card is scoped to Cage Twins
[22:31:48 +06m] plan - CageItemSpawner(+Model): replace fight/health-threshold/strip logic with a per-win option pair (authority writes serial/weapon index/taken, every client arms/disarms pads, untaken instance destroyed by its authority, winner's client heals on health take, expiry ring progress); Respawnable: IsRequestItemTaken + expiry progress; RespawnableCountdownUI: show expiry; CageController: heal-on-pickup flag, public StartSurvivorHeal, missing arm restored by item heal + ReinstantiateMechInPlace; GenericMechPickupper/ProximityPickup: revert 975b1d48e4; Cage Twins.unity: health pad per cage via bridge. QA: Cage Twins with Force Bot second player, win a round, capture both options + ring, take one, see the other vanish
[22:32:40 +07m] implemented - GenericMechPickupper.cs/ProximityPickup.cs: 975b1d48e4 reverse-applied (repair kit on a destroyed arm rebuilds the mech again)
[22:33:30 +08m] implemented - CageController.cs: SetSurvivorHealOnPickup skips the win heal; StartSurvivorHeal public; a missing arm gets the heal on its item + ReinstantiateMechInPlace
[22:34:00 +09m] implemented - Respawnable.cs: IsRequestItemTaken, SetExpiryProgress/TryGetExpiryProgress; RespawnableCountdownUI.cs shows expiry progress
[22:34:20 +09m] implemented - CageItemSpawner.cs + Model: option pair per win, take one removes the other, removal on reopen, health take runs the survivor heal, Niv's fight-start strip/cleanup removed
[22:37:18 +12m] compiled - clean (first compile request timed out on the bridge while the editor reloaded; second clean, 0 errors)
[22:41:02 +15m] implemented - Cage Twins.unity: "MP Respawnable Cage Health Option" pad (base Respawnable pad, prefab = Cage Health Reward, spawnOnRequest on) under each cage's Item Spawner/Items, wired to CageItemSpawner.healthPad
[22:44:00 +18m] scene - editor save also rewrote unrelated overrides (renderers disabled, font sizes); reverted and spliced only the 6 new objects + healthPad/removed fields + 2 m_Children entries; yaml-diff explain: 8 real changes; bake asset touched by the editor reverted
[22:45:08 +19m] verifying - scene reloaded, both healthPad refs resolve (spawnOnRequest on, prefab set); starting /qa with ~10 min
[22:47:56 +22m] play - Cage Twins ready, local mech spawned; no second player (Force Bot needs Multiplayer Play Mode)
[22:49:30 +24m] runtime setup - injected a Closed Cage row (holder = me) into Cage Left CageController._row; options serial 1: Wrecking Ball + Cage Health Reward Available, rings 0.57
[22:51:40 +26m] captures - 7 isolated-close, 1 isolated-wide-regression-check, 2 non-isolated-wide: weapon and health options on their pads, expiry ring visible
[22:52:10 +27m] take - consumed health reward: takenSerial=1 healthTaken=True, both pads Dormant, weapon option destroyed; 4 more captures
[22:53:00 +28m] round/expiry - Open->Closed spawned serial 2 pair (ring 0.94); Open removed both, 0 clones left; 2 regression-wide captures; check-captures OK (--no-regression: time, other scenes); console only FMOD/Photon mic errors; exited play
[22:54:46 +29m] report - PR file written; result inconclusive (real win/grab/heal/arm restore/death despawn not exercised)
[22:55:29 +30m] done - result JSON written

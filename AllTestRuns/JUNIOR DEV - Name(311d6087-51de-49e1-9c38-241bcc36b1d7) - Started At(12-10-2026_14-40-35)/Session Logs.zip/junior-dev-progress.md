title: Spectators shown on the cage leaderboard
result: inconclusive
phase: done
updated: 14:57:44 (+16m)

[14:41:12 +00m] started - source branch master, task: spectators appear on the cage leaderboard?; branch OK, only untracked junior-dev-full-process-debug.jsonl (workflow log)
[14:47:02 +05m] oriented - multiplayer: the cage leaderboard is the per-cage-room kills board (CageLeaderboard -> CageLeaderboardService -> server view MyCageRoomLeaderboard); job bug: card asks about unwanted existing behaviour
[14:47:02 +05m] reported case - a spectator session in a cage room is listed on that room's cage leaderboard; expected: only non-spectator players listed. Prediction of cause: spectators appear with 0 kills ranked after the players with kills
[14:47:02 +05m] cause - Cloud Code Projects/SpacetimeDB-Server-Rust/src/tables/cage_room_leaderboard_kills.rs:113: the zero-kill occupants loop walks every room session with no spectator check (the kills loop at :76 does filter spectators) | plan - skip spectators in that loop, like the weekly board (reducers/cage_weekly_leaderboard.rs:65); verify on a throwaway local SpacetimeDB
[14:47:40 +06m] implemented - cage_room_leaderboard_kills.rs:114: `if session.spectator || rankedPlayerIds.contains(...)` -> continue; no schema change, client untouched
[14:56:22 +15m] verifying - throwaway local SpacetimeDB (cagelb-test-*), temporary Dev_CageLb_Fixture reducer: room with viewer (3 kills), Player2 (0 kills), Spectator3, Spectator4 (has a kill row); subscribed to MyCageRoomLeaderboard as the viewer
[14:56:22 +15m] before fix - view returned 4 rows: Me #1, Player2 #2, Spectator3 #3 (0 kills), Spectator4 #4 (0 kills) - prediction matched, bug reproduced
[14:56:22 +15m] after fix - view returned 2 rows: Me #1 (3 kills), Player2 #2 (0 kills); spectators gone, ranks consecutive. Fixture removed (grep clean), test DBs deleted, local server stopped
[14:57:06 +15m] decision - no in-editor /qa: needs a second MPPM player joined as a spectator in the same cage room on a local server, no known setup path, not in budget; verdict inconclusive (no captures), server view behaviour verified directly
[14:57:44 +16m] reported - PR file and result JSON written, result inconclusive

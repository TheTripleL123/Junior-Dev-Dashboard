The bug is real and I fixed it, but the result is **inconclusive**. I tested the fix on a local test server only, not in the game with a real spectator, so there are no screenshots.

**Cause:** the server builds the cage leaderboard for each cage room. Players with kills are listed first, and that part already skipped spectators. Then it adds a 0-kill row for everyone else in the room, and that part didn't check for spectators. So every spectator ended up on the board with 0 kills.

**Fix:** that second step now skips spectators, the same way the weekly cage board already does. It's a one-line change in `Cloud Code Projects/SpacetimeDB-Server-Rust/src/tables/cage_room_leaderboard_kills.rs:114`. The data layout is unchanged and no client code changed.

**Test:** I set up a room with 2 players and 2 spectators on a throwaway local SpacetimeDB and read the leaderboard as one of the players.
- **Before the fix:** 4 rows, with both spectators at #3 and #4 with 0 kills. That's the reported bug.
- **After the fix:** 2 rows, just the two players, ranked 1 and 2.

Afterwards I removed the temporary test code (nothing of it is in the diff), deleted the test databases and stopped the local server.

**Not tested:** the leaderboard in the Unity editor with a live spectator. That needs a second client joined as a spectator in the same cage room, and I had no known way to set that up within the time budget.

**Needed after review:** the server module has to be published to dev for the fix to take effect. It's a normal publish with no migration. The PR description has the publish plan.

Files are in `C:\Users\CloudMachineC\Desktop\Cloud Machine C\_work\`:
- PR description: `_temp\PullRequest.txt`
- Result: `underdogs\underdogs\junior-dev-result.json`
- Journal: `underdogs\underdogs\junior-dev-progress.md`
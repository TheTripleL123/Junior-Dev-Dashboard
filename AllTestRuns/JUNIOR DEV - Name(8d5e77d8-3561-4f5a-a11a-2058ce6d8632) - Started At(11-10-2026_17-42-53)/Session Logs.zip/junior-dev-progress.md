title: Cinematic Viewer NRE spam in Rampage Arena
result: pass
phase: done
updated: 17:59:29 (+16m)

[17:43:19 +00m] started - source branch master, task: NRE spamming every frame from CinematicViewer.UpdateMechRecordingUI() in multiplayer (Rampage Arena)
[17:46:59 +03m] oriented - singleplayer: card says MULTIPLAYER but Rampage Arena is the singleplayer Rampage mode scene (.claude/game/singleplayer/game-modes.md), no MP scene in the screenshot's list; job bug: NRE spam is existing behaviour going wrong
[17:48:35 +05m] reported case - Cinematic Viewer(Clone) under the VR rig in Rampage Arena throws NullReferenceException every frame, top frame UpdateMechRecordingUI called from Update (screenshot), so not IsRecording/UpdateRecordTimer (UpdateRecordTimer runs first in Update and would throw first) | criteria - no NRE from UpdateMechRecordingUI with the viewer active in Rampage
[17:49:50 +06m] cause - CinematicViewer.cs:1423: before d72c4e45d2 (Oct 5) it read player.mechOS.recording.activeSelf unguarded; SP Mech OS.prefab (Assets/_Content/UI Combat/Mech OS/Mech OS.prefab:58383) has no recording/recordingTimer serialized, so recording is null every frame in SP. d72c4e45d2 added 'recording != null' and is already on master - the reporting build predates it. Dispatcher's MechReference/ThrottledTeardown theory ruled out: mechOS is typed MechOS (Unity null check catches a destroyed mech OS) and the MP Mech OS prefab has recording assigned. No code change needed
[17:50:01 +06m] compiled - editor ready, no compile errors, no code changed
[17:52:04 +08m] verifying - /qa with 14 min, configs Dev/No VR, Advanced/Multiplayer/PC Room Segregation, Game Modes/Quick Rampage, Combat/Dont Spawn Enemies, Combat/Invulnerable/God
[17:53:30 +10m] play - Rampage Arena ready, SP_PlayerMech (Gorilla Mech) with mech OS; mechOS.recording == null and recordingTimer == null confirmed at runtime
[17:55:36 +12m] runtime - Cinematic Viewer(Clone) spawned from Resources, opened via OnCinematicViewerChanged(true), quick mode on; frames 1648-1859 with zero NRE
[17:58:08 +14m] captures - 5 isolated-close (2 viewer: blank white screen in no-VR; 3 SP Mech OS panels), 0 regression (declared: needs MP session), 5 non-isolated-wide (mech in Rampage Arena); check-captures OK. Quick mode off and on, frames 1648-2297 total, console has no NullReferenceException and nothing from CinematicViewer. Exited play
[17:58:48 +15m] cleanup - reverted import-rewritten TemplateMenuItems.cs; tree clean; editor out of play
[17:59:29 +16m] done - pass, no code change (already fixed on master by d72c4e45d2), no PR file

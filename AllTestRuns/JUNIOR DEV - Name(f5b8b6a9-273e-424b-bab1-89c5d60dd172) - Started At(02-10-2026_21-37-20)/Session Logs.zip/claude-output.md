The fix is in and compiles cleanly, but the result is **inconclusive**: I never fired the real Left arm weapon or the Focused Blaster with Stun Lock equipped.

**Cause:** Stun Lock (`OverStun`) adds a modifier to the arm that turns stun into overheat. It only applies when the stun is credited to the arm. `GameEntity.AddStunDamage` credits the stun to whichever hit fills the stun meter last. Body hits and blast waves knock the enemy back, and its own crash into the ground often adds that last bit of stun, so the stun gets credited to the enemy itself. Jack's face is the exception: his headshot modifier multiplies stun (x15 +50), so one arm hit fills the meter on its own. That's why only that case worked. The crash part comes from reading the code; I didn't see it happen in play.

**Fix** (`Assets/Scripts/Combat/General/GameEntity/GameEntity.cs`): `AddStunDamage` now remembers the last stun contributor that isn't the enemy itself. If the enemy's own hit fills the meter, the stun is credited to that contributor, so Stun Lock and Over Stun on the arm apply. Every other case behaves as before. `GameEntity` is shared code, so this also runs in multiplayer; I didn't test multiplayer.

**What I tested** (singleplayer, Quick Rampage): I added a modifier to the left arm by hand with the Stun Lock asset's values, then fed stun into the enemies directly from the editor.

| Enemy | How the meter was filled | Stunned | Overheated |
|---|---|---|---|
| Junkdog | 60% from the arm, then 60% from its own crash | yes | yes (orange glow in captures) |
| Roach | its own crash only | yes | no (correct, nothing credited to the arm) |
| Roach | arm alone, in one go (like the Jack headshot) | yes | yes |

- I took 18 captures (`iso-close-*`, `scene-close-*`, `scene-wide-*`) and the capture check passed.
- The editor counted 1 console error that the log tool wouldn't display, so I don't know what it was.

**For the reviewer:** in a real run with Stun Lock on the Left arm, stun a non-Jack enemy with body hits and with the blast wave and confirm it overheats. If something other than the enemy's own crash finishes the meter, this fix won't cover it.

I reverted three `.uicss.meta` files the editor import had rewritten. The PR description is in `_temp\PullRequest.txt`, the result in `junior-dev-result.json` and the journal in `junior-dev-progress.md`.
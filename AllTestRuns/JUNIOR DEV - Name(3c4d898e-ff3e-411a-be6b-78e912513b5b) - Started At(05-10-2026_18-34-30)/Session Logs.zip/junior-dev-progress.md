title: GymBotArea bot spawn click race between clients
result: inconclusive
phase: done
updated: 18:55:12 (+20m)

[18:34:57 +00m] started - source branch master, task: GymBotArea Bot Spawn click race - use StringKeyDictionary so only one client spawns the mech, the other is rejected
[18:34:57 +00m] branch - on Automations/ClaudeJuniorDev/3c4d898e-ff3e-411a-be6b-78e912513b5b, no previous commits; only untracked junior-dev-full-process-debug.jsonl (workflow's log)
[18:41:26 +06m] oriented - multiplayer: GymBotArea is the MP gym (MpGym, SyncedMonoBehaviour). Reported case: two clients press the area's Spawn button at the same time, both spawn an NPC bot; expected one. Cause in GymBotArea.TryClaimSpawn: ownership is granted locally and the claim is a plain property write returning true at once, so both clients pass and both call TryInstantiateNPCMechAsync. Plan: replace model property 6 with a StringKeyDictionary<GenericDoubleModel> claim (deadline value) and spawn only after the server accepts the transactional insert (NPCMechSpawnManager.TryInsertAsync pattern)
[18:41:26 +06m] editor - unity_ready: ready, no compile errors
[18:42:33 +07m] implemented - GymBotArea.cs: model _spawnClaim StringKeyDictionary (id 6), TryClaimSpawnAsync awaits the insert callback (timeout = spawnClaimDuration), EndSpawnClaim removes the key; guides npc-mechs.md gap row + realtime-models.md exemplar updated
[18:43:49 +09m] compile - CS7036: StringKeyDictionary.Remove needs a completion handler; passed a no-op handler
[18:45:35 +11m] compiled - clean
[18:47:51 +12m] verifying - configs Dev/No VR, PC Room Segregation, Multiplayer/Levels/GYM; no MPPM virtual player active, single client
[18:48:02 +13m] play - GYM ready, 1 GymBotArea "Bot Area", local authority, no bot
[18:48:20 +13m] check - ConfirmCurrentSelection x2 in one frame: claim not visible locally right after insert (no optimistic apply), 4s later 1 NPC mech, hasBot true, claim removed. Console: 2x ObjectDisposedException from CancelAfterSlim timer firing on the disposed timeout CTS (mine), a 3rd at 10s from NPCMechSpawnManager's identical pattern (pre-existing)
[18:50:02 +15m] fixing - keep the CancelAfterSlim registration in a using so it is disposed before the CTS; recompiled clean
[18:51:14 +16m] play - GYM ready again
[18:51:27 +16m] check - two Insert("spawn") on model.spawnClaim in one frame from the bridge: callbacks first=True, second=False (server rejects the concurrent second claim)
[18:51:46 +16m] check - Spawn pressed twice in one frame: 1 NPC mech, hasBot true, claim entry removed; no new console errors (6 boot-time audio/voice errors only)
[18:52:30 +17m] captures - 5 isolated-close + 4 non-isolated-wide: one Proteza NPC on the pad, button reads KILL
[18:52:52 +17m] regression - Kill pressed -> hasBot false, 0 live NPCs; Spawn pressed -> 1 live NPC, claim removed
[18:53:06 +18m] captures - 4 isolated-wide-regression-check of the respawned bot; check-captures OK. Console: 1 ObjectDisposedException (CancelAfterSlim timer), consistent with NPCMechSpawnManager's 10s allocation timeout, none at 3s after the presses
[18:53:31 +18m] exit play - stencil off, lease released; reverted 6 import-rewritten .uicss.meta files
[18:55:12 +20m] two-client case - not run: no MPPM virtual player configured (clones list empty), and booting one does not fit the budget
[18:55:12 +20m] done - PR file and result written: inconclusive (mechanism and single-client paths verified, two-client press not run)

The fix is in and compiles, but the result is **inconclusive**. I never ran the actual case of two different clients pressing Spawn at the same time, because this machine has no second Multiplayer Play Mode player set up.

**Cause:** In `GymBotArea.TryClaimSpawn`, each client took ownership of the area locally, wrote the claim and went ahead without waiting for the server. When two clients pressed together, both spawned a bot.

**Fix (`Assets/__Multiplayer/Scripts/MpGym/GymBotArea.cs`), done the way Nisan asked:**
- The area's model now holds the spawn claim in a `StringKeyDictionary<GenericDoubleModel>`, under one key whose value is the claim's expiry time. It still expires on its own after 3 seconds, so a client that leaves mid-spawn can't block the area.
- `TryClaimSpawnAsync` inserts the claim and waits for the server's answer before spawning. When two inserts arrive together, the server accepts the first and rejects the second, so the second client doesn't spawn. If the server doesn't answer within 3 seconds, it logs an error and doesn't spawn.
- When the spawn finishes, the claim is removed.

**What I tested in the GYM level (one editor):**
- Two claim inserts sent in the same frame: the first was accepted, the second rejected.
- Spawn pressed twice in the same frame: exactly one bot, and the button switched to KILL.
- Kill, then Spawn again: one new bot. The 13 screenshots passed the capture check.
- My first version logged an `ObjectDisposedException` 3 seconds after each claim. One fix round removed it. `NPCMechSpawnManager` has the same bug and I left it alone.

**Still to do:**
- **Two-client test:** two clients press Spawn in the GYM at the same moment, expecting one bot.
- **Edge case:** the losing client's ownership request can leave it owning the area. The winner then can't remove its claim, so Spawn stays disabled for up to 3 seconds. Fixing that means letting any client write the claim without owning the area, like `NPCMechSpawnManager` does. That would change who controls the area's mode buttons, so I left it out.

I also updated the two guide pages that tracked this issue (`npc-mechs.md`, `realtime-models.md`). I reverted the `.uicss.meta` files the editor rewrote during import. The PR description and result JSON are written for the workflow.
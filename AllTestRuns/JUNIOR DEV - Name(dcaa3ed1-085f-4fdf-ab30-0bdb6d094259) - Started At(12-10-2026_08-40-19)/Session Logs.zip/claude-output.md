**PASS.** The fix is redone on the work branch and verified in the editor. As asked, I made no commit, push or PR; the changes are left on disk for the workflow.

**Cause:**
- **Dying player's dropped arm:** when an arm falls off, its parts are still on the dead mech's list of things to paint. When the dead mech's paintshop shuts down, it wipes paint from everything on that list, including the dropped arm. That only runs on the dying player's own screen, which is why other players still see the paint.
- **Respawned arms:** arms that join a mech after its paint has already arrived were never painted.

**What changed:**
- `MP_MechArm.Detach()` takes the arm off the dead mech's paint list (`PaintRendererSet.FindEntitySet(mechEntity)?.RemoveRenderersUnder(transform)`).
- `PaintRendererSet` remembers the last paint it applied, forgets it when paint is cleared, and applies it to arms that join afterwards in `TryMergeIntoParentSet`.

**How it was checked:** two players in Joint, with a script reading each paint slot's on/off value (`_WhiteParams`).
- After the main player died, all 4 of their dropped-arm parts were still painted on their own screen, and the respawned mech's arms were painted.
- Player 2 also saw those dropped arms painted.
- When Player 2 died, their dropped arms stayed painted for the main player.
- 21 screenshots were kept, and the console showed only microphone-driver errors unrelated to paint.

**Gaps:**
- The test profiles have no real paint design, so I used a red test texture in place of a downloaded design.
- The dying player's own dropped arms come out dark in the screenshots because they lie in the unlit spawn elevator. The proof for them is the paint values, not the pictures.
- I didn't test the respawned-arm fix on its own in the exact order where a cached download paints the mech before the arms join. The respawned arms were painted, but the paintshop's own repaint may have covered that.

The PR description is at `_work/_temp/PullRequest.txt` and the result is in `junior-dev-result.json`.
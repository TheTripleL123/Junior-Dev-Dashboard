title: Stun bar not updating on junkdog/jungledog variants
result: aborted
phase: done
updated: 12:03:30 (+23m)

[11:40:53 +00m] started - source branch master, task: stun bar UI doesn't update on hits for junkdog variants (except base/bloodhound) and jungledog variants (except base)
[11:40:53 +00m] git - on Automations/ClaudeJuniorDev/1cb134ce-..., no prior commits; untracked junior-dev-full-process-debug.jsonl (workflow debug file, not mine)
[11:57:22 +16m] oriented - singleplayer: task names SP junkdog/jungledog bots. /game-context traced hit -> DamageHandler -> root GameEntity.AddStunDamage -> BotHealthBar.UpdateStun -> HealthBarUI; found no divergence between working and broken prefabs
[12:02:18 +21m] investigated - prefab override diff: the only data override shared by every affected variant and missing from working ones is CreatureID.difficulty/prefabName (only read by spawn budgeting and MP heat field); archetype.boundComponents overrides are stale (target no longer in base). stunBuffer, BotUISpawner, parent chain identical. Turbo/Spiked/Armored add unrelated objects
[12:03:30 +23m] aborted - cause not found in code/data; no code changed. Needs a runtime comparison (not allowed before a change exists)

I couldn't find the cause from the code or the prefab data, so I aborted (`cause not found`). I changed no code and didn't write a PR file.

**The stun bar path, traced end to end (SP bots):**
1. **Hit:** `DamageHandler.ConsumeGenericDamage` calls `GameEntity.AddStunDamage` on the enemy's root entity. That raises `stunDamage` and stuns the enemy when it reaches `stunBufferSize`, which is set from `BaseEnemyEntity.stunBuffer` in `Awake`.
2. **UI setup:** `BotUISpawner` spawns a pooled `Bot UI`. `BotHealthBar.Setup` picks the stun source with `GetComponentInParent<IStunComponent>()`, falling back to the root, and sets the bar's max once.
3. **Each frame:** `BotHealthBar.UpdateStun` (`Assets/Scripts/Combat/UI/BotHealthBar.cs:251`) sends `stunDamage` to `HealthBarUI`.

**What I compared:** the working prefabs (`Junkdog`, `Junkdog - Bloodhound`, `JungleDog`) against every affected variant in both families: Spiked, Armored, Armored-Left/Right, Turbo, Turbo Spiked and Turbo Armored.
- The stun buffer value, where `BotUISpawner` sits and the entity parent chain are the same in all of them.
- The only overrides every broken variant has and no working one has are `CreatureID.difficulty` and `prefabName`. In SP code, only spawn budgeting reads `difficulty`; nothing on the stun or UI path reads either field.
- The variants' `archetype.boundComponents` overrides point at a component that no longer exists in the base prefab. They're leftover data and don't affect anything.
- The objects that Turbo, Spiked and Armored add don't change what the bar reads.

**Next step:** this needs a runtime comparison, which the junior-dev rules don't allow before a change exists. In Play mode, spawn `Junkdog` next to `Turbo Junkdog` and `Junkdog - Spiked`, hit each one, and compare per frame:
- whether `BotHealthBar._stunComponent` is the root entity;
- the root's `stunDamage` and `stunBufferSize`;
- the stun bar `HealthBarUI`'s `_maxHealth` and `_currentHealth`.

That shows whether the problem is in the hit path or in the UI.

The orientation step alone took about 16 minutes. The journal and result JSON are written to the paths you gave.
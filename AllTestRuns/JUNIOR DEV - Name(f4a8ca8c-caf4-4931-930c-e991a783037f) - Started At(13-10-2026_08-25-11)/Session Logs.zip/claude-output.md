I fixed the kill count bug and verified it in the editor: 2999 kills now shows **3.0K** instead of **2.10K**. Result is **pass**.

**Cause:** the bug is in `Concat(float, decimal_places, ...)` in `StringBuilderExtNumeric.cs`, not in `StringBuilderExtFormat.cs` as the card says. `StringBuilderExtFormat.cs` only sends float values to that function. The function wrote the whole-number part first, then rounded the digit after the dot on its own, so the rounding never carried over (2.999 became "2" + "10"). Any count whose first decimal rounds up was affected (1950 showed 1.10K), and the same goes for M values.

**Fix:** the function now rounds once at the requested precision, then writes the whole number and the zero-padded decimals separately. It still allocates nothing. Two smaller bugs in the same code are fixed too:
- **Missing leading zeros:** 2.05 printed as "2.5", and 1.00001 printed as "1.1" at the default 5 decimals.
- **Lost minus sign:** values between -1 and 0 printed without it.

This function is shared, so any SP or MP text that hit one of these cases now prints correctly. Values that already printed correctly are unchanged. The file is in the One Humus submodule, so the workflow will open a PR there too.

**Verification:**
- **Edit mode:** I ran the real formatter on a set of values. 2999 → 3.0K, 2900 → 2.9K, 1950 → 2.0K, 2,960,000 → 3.0M. Default-decimal, two-decimal, negative, padded and zero-decimal output all came out right.
- **In play (Joint):** I didn't write the dev SpacetimeDB, so I didn't use real kill stats. Instead I turned off the update script on the player's kills label and wrote to the label with the same call the game uses. It read 3.0K, 2.9K and 2.0K, and I took 16 screenshots. The 5 wide environment shots were blocked by level geometry and don't show the label.
- **Console:** no errors from the change. The ones present are unrelated: no microphone on the cloud machine, and an unassigned `ColliderIgnoreGroup` reference.

**Left open:**
- The BallTag all-time score display uses the same format. The edit-mode check covers it, but I didn't show it in play.
- Counts from 999,950 to 999,999 now show "1000.0K", because the label only switches to M at 1,000,000. Before, they showed "999.10K". Lowering that threshold would fix it.
- The card doesn't say whether 2999 should read 3.0K or 2.9K. I kept rounding, since that's what the format string asks for and what .NET does.

The PR description is in `PullRequest.txt` and the result is in `junior-dev-result.json`.
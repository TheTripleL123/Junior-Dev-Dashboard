**Aborted: cause not found. No code changed and no PR file written.**

I couldn't reproduce the bug. In Play mode I put Stun Lock (`Addon - Stun Crashers`) on the left arm through the loadout and rebuilt the mech, then sent the hits from code:
- **Left-arm punches on a Junkdog:** when a punch filled the stun bar, the dog got Stun 1.5 s and Overheat 1.5 s together.
- **Focused Blaster blast wave, blaster on the left arm:** the shockwave hits that filled the bar did the same.
- **Jack body hits:** stun and overheat started and ended together.
- **The only stun without overheat** came from an arena floor spike. That's an environment stun, which Stun Lock isn't meant to affect.

Real punches come from `SP_PlayerPunchBehavior` on the effector, which sits under the arm. So they go through the same "did this arm cause it" check as the hits I sent, and that check passed every time.

I didn't send Jack face hits, so the "only Jack face hits work" difference wasn't observed. The bug may come from something I couldn't test:
- **The final hit came from the other arm, or from a crash into scenery.** Stun Lock only reacts to stuns its own arm causes. A Jack face hit adds enough stun to fill the bar in one hit, which could be why only that case works reliably. If Stun Lock should overheat every stunned enemy, that's a design change, not a bug fix.
- **The overheat showed but ended early.** A bot's stun timer pauses while it's in the air, but its overheat timer keeps running (`GameEntity.PropagateStatusEffects`). A dog knocked into the air can stay stunned after its overheat has run out.
- **The Focused Blaster was on the right arm**, where Stun Lock on the left arm doesn't apply.

These go back to the reporter as next steps in the result JSON.

The editor's import had rewritten three `.uicss.meta` files; I reverted them, so the working tree has only the journal and the workflow's own log. I left Play mode and released the editor. The journal and `junior-dev-result.json` are written.
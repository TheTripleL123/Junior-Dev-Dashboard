title: Winner gets x5 turbo instead of x1
result: pass
phase: done
updated: 14:04:25 (+13m)

[13:51:23 +00m] started - source branch master, task: winner should have x1 turbo not x5; branch ok, tree clean except workflow's junior-dev-full-process-debug.jsonl
[13:53:40 +02m] oriented - multiplayer: the only winner turbo is DeathmatchController's (Rumble) winner bonus round, MP-only code; job bug: card's JOB TYPE says bug fix (wrong existing value)
[13:53:40 +02m] reported case - Deathmatch winner during the bonus round gets turbo x5 on arms; should be x1 (chassis already 1)
[13:53:40 +02m] cause - DeathmatchController.Bonus.cs:174-175: ApplyWinnerTurbo calls SetTurboDuration(5, ...) on both arms; predicts arm turbo count 5 for the bonus round, every time the winner turbo is applied - matches the report
[13:53:58 +02m] implemented - DeathmatchController.Bonus.cs: both arms SetTurboDuration(5 -> 1, ...)
[13:56:27 +05m] compiled - clean (editor ready, 0 errors)
[13:56:53 +05m] verifying - /qa with 25 min; local SpacetimeDB up (Dev_ reducers are writes, not run on dev)
[14:00:30 +09m] play - configs Dev/No VR, PC Room Segregation, Local SpaceTimeDB, Multiplayer/Levels/Shithole; Shithole Rumble ready, deathmatch Active, solo player id 1
[14:01:19 +10m] scenario - Dev_DeathmatchStartBonus(room, 1, winner 1) on local: bonusActive=True winner=True, arms L=1 R=1 chassis=1, isTurbo=True
[14:01:30 +10m] regression - Dev_DeathmatchSetTimeRemaining(300) re-applies ApplyWinnerTurbo: still L=1 R=1 chassis=1
[14:02:08 +11m] captures - 5 isolated-close, 3 regression-check, 3 non-isolated-wide: winner mech arms purple/blue with turbo arcs
[14:02:29 +11m] regression - Dev_DeathmatchFinishBonus(survived): final standings, turbo L=0 R=0 chassis=0
[14:03:02 +12m] captures - 1 isolated-close, 2 regression-check, 1 non-isolated-wide at final standings; check-captures OK; console: no errors from the change (FMOD mic, DMGFX controller, MP_KillPlane MissingReference, first local connect race - unrelated)
[14:03:21 +12m] exited play - configs restored, local SpacetimeDB down, editor on dev
[14:04:25 +13m] done - PR file and result written, result pass

The Deathmatch winner now gets x1 turbo during the bonus round instead of x5, and I tested it in the editor: **pass**.

- **Cause:** after a Deathmatch round, the winner's bonus round gave each arm 5 turbo stacks. That number was hard-coded in `DeathmatchController.Bonus.cs:174-175`. The chassis already got 1.
- **Fix:** both arms now get 1 stack. That one file is the whole change. Turbo is applied only on the winner's own client, so the server needs no change.
- **Test:** I ran it in Shithole Rumble against a local test server, because the dev commands that start a bonus round write to the database. Nothing was written to the shared dev database.
  - When the bonus round started, the winner's turbo was 1 on each arm and 1 on the chassis.
  - After I changed the bonus timer, which applies the turbo again, it was still 1.
  - At the final standings the turbo cleared to 0.
  - The check script accepted the 15 screenshots, and the project compiled with no errors.
- **Console:** the errors that showed up don't come from this change. They were microphone errors (the machine has no audio device), DMGFX "cannot find a controller", an `MP_KillPlane` missing-reference exception, and a connection race with the local server at startup.
- **Not checked:** whether 1 stack feels right in play needs someone to play it.

The editor is out of Play mode, its debug configs are back to how I found them, and the local server is stopped.

Files are in `C:\Users\CloudMachineA\Desktop\Cloud Machine A\_work\`:
- `_temp\PullRequest.txt`
- `underdogs\underdogs\junior-dev-result.json`
- `underdogs\underdogs\junior-dev-progress.md`
- `_temp\junior-dev-screenshots\`
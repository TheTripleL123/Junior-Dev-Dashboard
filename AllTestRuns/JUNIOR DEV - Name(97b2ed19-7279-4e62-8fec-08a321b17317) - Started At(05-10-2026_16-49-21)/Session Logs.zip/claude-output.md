I fixed the bug and tested the fix in the editor in Rampage; the result is **pass**.

**Cause:** in the loadout screen (`MechUI`), the swap only checked that the addon you drag can go where you drop it. The addon it pushes out was moved into the dragged addon's old slot without any check. Some addons are allowed on both the arm and the body (Weight Pack, Gash Bang, Magshot and five others). If one of those is in the body and you drop it on an arm addon, the arm addon moves into the body. That is how Overdrives, Megafrictor and Major Cabal reached the body, and the reverse move put Phantom Limb and Triple Bus on an arm. Dropping one of these addons straight onto the wrong slot was already blocked.

**Fix:** in `Assets/Scripts/Run/Controllers/Garage/MechUI.cs` (`DetermineAction`), a swap between two mech slots now also checks that the pushed-out item is allowed in the other slot. This reuses `CanSwap`, the check the inventory route already used. If the check fails, the slot is dimmed and dropping on it does nothing. That one file is the only change.

**Testing:** I opened the Rampage level-up shop and set up the addons from code, without VR.
- **Weight Pack in the body:** it can no longer swap with Overdrives or Megafrictor on the arm. Trying it leaves the loadout as it was.
- **Weight Pack on an arm:** it can no longer swap with Phantom Limb in the body.
- **Normal moves:** arm-to-arm swaps, swaps between two addons allowed in both slots, and equipping into empty slots still work.
- **Evidence:** 20 screenshots, and the console shows no game errors.

**Not covered:**
- Major Cabal and Triple Bus weren't equipped in the test. They're limited to arm and body the same way as Overdrives and Phantom Limb, so they go through the same check.
- I didn't test swapping from the inventory, because the Rampage shop shows no inventory slots. That path is unchanged.
- Saved runs that already have an addon in the wrong slot are not corrected.

I reverted six `.meta` files the editor had rewritten on import. The PR description, result file and progress journal are written for the workflow to commit and push.
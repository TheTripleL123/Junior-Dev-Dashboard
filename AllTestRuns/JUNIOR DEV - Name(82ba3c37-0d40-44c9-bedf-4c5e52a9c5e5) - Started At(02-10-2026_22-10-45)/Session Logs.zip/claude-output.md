I've made a fix that compiles cleanly and works in scripted tests, but I'm reporting it as **inconclusive**. I couldn't use real VR hits here, and I couldn't connect the report's "only Jack/face hits work" to anything in the code.

**Cause:** Stun Lock is an arm addon (`OverStun`). Its setup attached the Stun-to-Overheat conversion only to the arm it's socketed in (`OverStun.cs:26`). The conversion (`DamageModifier.cs:65`) only applies to stuns that come from inside that arm. So stuns from the other arm, that arm's weapon, or its Focused Blaster blast waves never got converted. Before changing anything, I checked this in the running game: with Stun Lock on the left arm, stuns from the left weapon, a left punch and a real shockwave owned by the left weapon all converted correctly.

Nothing in the code treats Jack or face hits specially. My best guess is that the reporter's working hits came from the arm Stun Lock was in, but I haven't confirmed that.

**Fix:**
- **`OverStun.cs`:** added an `applyToWholeMech` option that attaches the conversion to the whole mech instead of the one arm.
- **`Addon - Stun Crashers.asset`** (Stun Lock): turned that option on. Over Stun uses the same class but stays per-arm, and it still extends the stun before Stun Lock converts it.

**Test:** Quick Rampage with Junkdogs, Stun Lock equipped into the **right** arm the way the game normally does it.
- A left punch stun: stunned and Overheated.
- A real Focused Blaster shockwave owned by the left weapon: stunned and Overheated. The health bar shows both the Overheat and Stun icons in `iso-close-junkdog104-shockwave-left-overheated-90.png`.
- A right-arm stun, to check the old case still works: stunned and Overheated.
- 12 screenshots, and the capture check passed. Three of the four wide shots have the bot hidden behind geometry.
- No console errors come from the change. Some errors appeared only because the hits were scripted: a punch with no collider, and shockwaves I spawned by hand being cleaned up on exit.

**Needs a human in a headset:**
- Stun enemies with the arm that *doesn't* have Stun Lock, and with a Focused Blaster slam from either arm. Each should Overheat.
- Stun Lock now keeps working after the arm it's socketed in is destroyed.
- Stuns from crashing or throwing enemies still don't convert. I left that alone as out of scope.

Files are in place:
- PR description: `_work\_temp\PullRequest.txt`
- Result: `junior-dev-result.json`
- Journal: `junior-dev-progress.md`
- Screenshots: `_work\_temp\junior-dev-screenshots`

The working tree contains only the two changed files. I reverted three `.meta` files the editor import had rewritten.
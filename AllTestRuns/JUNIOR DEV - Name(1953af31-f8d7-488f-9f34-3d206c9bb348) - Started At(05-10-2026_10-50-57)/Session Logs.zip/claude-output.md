I fixed the stun bar on the Spiked and Armored Junkdog and JungleDog variants and checked it in the editor. Result is **pass**. The plain Turbo variants had no frozen bar to fix: I couldn't reproduce the problem on them.

**Cause:** Spikes and armor add a helper object (`EntityProxy`) to the dog's rib cage and body when it spawns. The bot's bar takes its stun value from the nearest object above it in the hierarchy (`BotHealthBar.cs:169`). On these variants that was the helper, whose stun never changes, so the bar stayed empty. Meanwhile the dog's own stun kept building and stunned it.

**Fix:** a one-line change in `Assets/Scripts/Combat/UI/BotHealthBar.cs`. If the object the bar finds can't take status effects, the bar reads the dog itself instead. Objects that can be stunned on their own are still read as before, Cerberus heads for example.

**Verification** (singleplayer, Quick Rampage):
- **Before the fix:** Spiked and Armored bars read the helper and stayed at 0 while the dog's stun was 16.5 of 50.
- **After the fix:** I spawned all 14 reported variants plus base Junkdog, Bloodhound and base JungleDog, and added the same amount of stun to each. All 17 bars matched the dog's actual stun value.
- **Screenshots:** the mint stun line visibly fills on Junkdog Spiked, Turbo Junkdog Armored and JungleDog Armored-Left. The three dogs that already worked still show it normally (23 screenshots).
- **Stun still works:** filling a Spiked Junkdog's stun bar still stuns it.
- **Console:** the only errors were 5 "Could not find prefab" lines from config names I guessed wrong while spawning, not from the change.

**Plain Turbo Junkdog / Turbo JungleDog:** I changed nothing for them. Their bar already read the dog and moved, at half speed because turbo halves incoming stun. That slow fill may be what was reported for them.

The journal, result file and PR description are written, and the only changed file is `BotHealthBar.cs`. The editor's import had rewritten three unrelated `.uicss.meta` files; I reverted them.
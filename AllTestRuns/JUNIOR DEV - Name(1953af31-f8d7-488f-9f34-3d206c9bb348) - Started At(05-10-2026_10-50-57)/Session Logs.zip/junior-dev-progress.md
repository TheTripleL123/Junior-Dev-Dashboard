title: Stun bar not updating on most junkdog/jungledog variants
result: pass
phase: done
updated: 11:07:27 (+16m)

[10:51:22 +00m] started - source branch master, task: some enemies' stun bar does not change but they still get stunned (junkdog variants except base/bloodhound, jungledog variants except base). Branch OK, no previous commits; untracked junior-dev-full-process-debug.jsonl is the workflow's log.
[10:57:23 +06m] reported case - enemies: SP Junkdog Spiked/Armored(Both/Left/Right)/Turbo/Turbo Spiked/Turbo Armored and the same JungleDog variants; input: any hits that build stun; symptom: stun line on the bot bar never grows, yet the bot gets stunned after enough hits; expected: line grows with stun; works: base Junkdog, Bloodhound, base JungleDog.
[10:57:23 +06m] oriented - singleplayer: task names SP bots. Bar reads stun from BotHealthBar._stunComponent = GetComponentInParent<IStunComponent>() (BotHealthBar.cs:169) from RibCage/BotUISpawner. JunkDogSpikes.Start and ArmorEntity.SetupArmorProxies add an EntityProxy (a GameEntity, so an IStunComponent with stunDamage always 0) on RibCage/Pelvis/PhysicsRig - predicts bar frozen on Spiked/Armored while the root entity still stuns. Plain Turbo variants have no spikes/armor - not explained by code yet. Editor ready, no compile errors.
[10:58:30 +07m] runtime check - question: what does BotHealthBar._stunComponent point to on Junkdog Normal/Spiked/Turbo/Armored Both, and does the stun bar value follow root.stunDamage?
[11:00:07 +08m] play - Quick Rampage ready (No VR, PC Room Segregation, Dont Spawn Enemies, God); spawned the 4 junkdogs.
[11:00:40 +09m] runtime check answer - Spiked: EntityProxy on RibCage; Armored: EntityProxy on PhysicsRig; Normal and Turbo: the JunkDogEntity root. After AddStunDamage(20): Spiked/Armored bar cur=0 max=100 while root stunDamage=16.5; Normal bar=16.5/50; Turbo bar=6.5/50 (halved by turbo, moves). Exited play. Cause: proxy hijacks the stun lookup (JunkDogSpikes.cs:30, ArmorEntity.cs:164). Plain Turbo bar not frozen - not reproduced.
[11:01:31 +10m] implemented - BotHealthBar.cs Setup: fall back to the root entity when the found IStunComponent is a GameEntity without status effects.
[11:02:42 +11m] compiled - clean (0 errors). Reverted 3 import-rewritten .uicss.meta files.
[11:04:00 +13m] verifying - inline /qa, configs Dev/No VR, PC Room Segregation, Quick Rampage, Dont Spawn Enemies, Invulnerable/God; play ready.
[11:04:40 +13m] scene ready - spawned all 14 reported variants + Junkdog, Bloodhound, JungleDog via CombatDebug.InstantiateBot, Force Sit (Strict). After AddStunDamage(20): all 17 bars read the JunkDogEntity root and bar value == root.stunDamage (e.g. Spiked 18.4/50, Turbo Armored 8.4/50, JungleDog Armored-Left 17.7/70).
[11:05:32 +14m] captures - 10 isolated-close (Junkdog Spiked, Turbo Junkdog Armored, JungleDog Armored-Left): mint stun line filling from the right end; 7 isolated-wide-regression-check (Junkdog, Bloodhound, JungleDog): stun line shows as before; 6 non-isolated-wide. check-captures OK (23).
[11:06:16 +15m] stun still triggers - filling Junkdog Spiked's buffer stuns it (isStunned=True). Console: only 5 "Could not find prefab" errors from my own wrong config-name guesses. Exited play, released the editor.
[11:07:27 +16m] done - PR file and result JSON written, result pass.

title: Arm paint missing on dropped and respawned mech arms
result: pass
phase: done
updated: 18:03:33 (+14m)

[17:49:37 +00m] started - source branch master, task: missing arm paint after player dies (dropped arm unpainted for dying player, respawned arm unpainted)
[17:49:37 +00m] branch - on work branch, only untracked junior-dev-full-process-debug.jsonl (workflow's own debug log, not task work) - proceeding
[17:52:55 +03m] oriented - multiplayer: card says PVP, code is Assets/__Multiplayer/Scripts/Mech/Paintshop + MP_MechArm/MP_PlayerMech; job bug: card is labelled Bug and reports paint that used to show going missing
[17:52:55 +03m] reported case - (1) player killed, arm detaches as debris: owner sees debris arm without paint (polish stays), remote viewers see it painted; (2) after respawn the new mech's arm has no paint (rest of mech painted)
[17:52:55 +03m] cause 1 - PaintshopCompositor.cs:334 OnDisable -> ClearOutputTextures -> PaintRendererSet.ClearTextures (PaintRendererSet.cs:74, :147) sets _WhiteParams=0 on every renderer in the root set; arm renderers were merged in (TryMergeIntoParentSet :193) and MP_MechArm.Detach (:1418) never removes them, so the dying mech's teardown unpaints the debris arm. Only the owner has a compositor (stripped on remotes, MP_PlayerMech.cs:752) -> only owner sees it; polish is PropertyBlockMaterialSwapper, untouched
[17:52:55 +03m] cause 2 - PaintTextureSynchronizer.OnReadyForUse (:102) runs on synchronizer readiness, independent of MP_PlayerMech.ThrottledSetup -> InitializeSetup (:728) -> SetupArms; a disk-cache hit (PaintTextureCloudProvider.cs:132) applies same frame to the root set before arm sets merge (PaintRendererSet.Start), and nothing re-applies after a merge (AppliedUrl early-out :301)
[17:52:55 +03m] plan - PaintRendererSet: remember last applied color/surface, re-apply them to a child set's renderers when it merges, forget them on ClearTextures; add RemoveRenderersUnder(Transform) + FindEntitySet; MP_MechArm.Detach removes the arm's renderers from the mech's root set next to RemoveRenderersFromCullingList. QA: dying owner's debris arm keeps _WhiteParams=1 after mech teardown; respawned arm renderers have _WhiteParams=1
[17:53:30 +04m] implemented - PaintRendererSet.cs: _appliedColorTexture/_appliedSurfaceTexture set in ApplyTextures, reset in ClearTextures, re-applied in TryMergeIntoParentSet; new FindEntitySet + RemoveRenderersUnder. MP_MechArm.cs Detach: removes arm renderers from the mech's root paint set
[17:54:45 +05m] compile - first bridge request timed out (I/O deadline), editor ready, retried
[17:56:07 +07m] compiled - clean (0 errors)
[17:56:48 +07m] verifying - /qa with 22 min, configs Dev/No VR, Advanced/Multiplayer/PC Room Segregation, Multiplayer/Levels/Joint
[17:58:09 +08m] play - Joint, local mech spawned; arms attached, Cover slot _WhiteParams=1 on body + both arms, root set holds 7 renderers
[17:59:54 +10m] case 1+2 - Combat/Multiplayer/Die; within 20 s old mech destroyed and new mech spawned; 4 debris arm renderers (no mech parent) _WhiteParams=1; new mech arms _WhiteParams=1
[18:00:56 +11m] captures - 7 isolated-close, 6 isolated-wide-regression-check, 6 non-isolated-wide: profile has no custom design, so painted cover looks grey-brown on both debris and new arms; check-captures OK
[18:01:42 +12m] case 1 again - red test texture pushed via root set, second Die: all 8 debris arm renderers _WhiteParams=1, new mech arms _WhiteParams=1; red not visible in the 2 extra shots (compositor output re-pushed or first debris framed)
[18:02:10 +13m] console - only FMOD/Photon Voice mic-driver errors (no audio input on cloud machine); exited play, control released
[18:03:33 +14m] reported - PR file and result JSON written, result pass

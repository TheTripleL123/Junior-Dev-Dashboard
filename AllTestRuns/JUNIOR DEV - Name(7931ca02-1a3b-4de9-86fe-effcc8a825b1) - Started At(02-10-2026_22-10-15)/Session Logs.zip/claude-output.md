The stun bar now updates on the affected variants. The fix is one change in `Assets/Scripts/Combat/UI/BotHealthBar.cs`; stun logic and thresholds are untouched. It compiles clean, and I verified it in Play mode. Result: **pass**.

**Cause:** the Spiked and Armored variants have an extra proxy entity (`EntityProxy`) on the rig: on `RibCage` for Spiked, on `PhysicsRig` for Armored. When the health bar sets up, it takes the nearest entity above it as its stun source, which on these variants is that proxy instead of the bot itself. The proxy never takes stun damage, so the bar sat at 0 while the bot's real stun value rose and stunned it as normal. I confirmed this in the running game before changing anything: Spiked and Armored bars pointed at the proxy, while the base Junkdog, Bloodhound, base Jungledog and Turbo Junkdog pointed at the bot.

**Fix:** if the stun source it finds is an entity that can't take status effects, `BotHealthBar.Setup` now moves up to the parent entity until it reaches one that can. This works the same way as the health lookup just above it. Bots that were already working don't hit this path.

**Verification:**
- I spawned Junkdog, Bloodhound, Junkdog Spiked, Armored and Turbo, plus Jungledog, Jungledog Spiked and Armored-Left, and applied 30 stun damage to each.
- Every bar now reads from the bot itself, and its value matched the bot's stun damage: about 28/50 on Junkdogs, 27/70 on Jungledogs, 13/50 on Turbo (turbo halves stun damage).
- 19 screenshots show the stun bar partly filled on the fixed variants, the same as on the base ones. No new console errors.

**Not covered:**
- Friendly, Pet, XMas, Turbo Spiked, Turbo Armored and Jungledog Armored Both weren't spawned one by one. They either have no debug spawn action, or it's broken: Jungledog Armored Both logs `Could not find prefab`. They're built on the same rig as the variants I tested.
- Plain Turbo Junkdog already worked before the fix. Its bar fills at half speed because turbo halves stun damage, which may be why it looked static.
- I tried a full stun on the patched Spiked bots to confirm the stun still triggers, but the call failed without an error, so that isn't confirmed. The stun-trigger code isn't touched by this change.
- The multiplayer `PlayerHealthBar` looks up its stun source the same way; I left it alone since multiplayer was out of scope.

I reverted the three `.uicss.meta` files the editor import rewrote, so the working tree holds only the fix and the journal.

Files are in `C:\Users\CloudMachineC\Desktop\Cloud Machine C\_work`:
- `_temp\PullRequest.txt`
- `underdogs\underdogs\junior-dev-result.json`
- `underdogs\underdogs\junior-dev-progress.md`
- `_temp\junior-dev-screenshots`
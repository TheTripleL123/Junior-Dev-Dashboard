title: HumusAsset scene overrides not baked into builds
result: inconclusive
phase: done
updated: 18:53:02 (+18m)

[18:34:25 +00m] started - source branch master, task: HumusAsset fields overridden in scenes keep the prefab's stored path, so builds spawn the original prefab
[18:34:25 +00m] branch ok - Automations/ClaudeJuniorDev/52a9a91a-..., no earlier commits; only the workflow's junior-dev-full-process-debug.jsonl untracked
[18:40:21 +06m] reported case - build-enabled MP test levels (Falloff 36, Parking 18, Blockeria 16, Crossy 7, Red Arena 5, ...) override HumusAsset.prefab on scene instances of Respawnable / MultiplayerSpawnEntity / ZoneSpawnOnCompletion / PurchaseSpawnController with no projectPath override; expected: build spawns the override prefab
[18:40:21 +06m] oriented - multiplayer (MP spawners), build-step editor code. Cause: HumusAssetProcessor.RunHumusAssetProcessors stamps projectPath via RunProcessor only on assets/prefabs (ScanFields: FindAssets + prefab sweep), never on scene objects; scene instances inherit the source prefab's stamped projectPath, and HumusAsset.LoadAsset in players loads Resources by projectPath -> original prefab. Also ApplyHumusAssetProcessor ignores HumusAsset[] fields (ZoneSpawnOnCompletion.prefabAssets, LootBox.prefabs). Predicts: editor spawns override (prefab.asset), player spawns source prefab - matches report
[18:40:21 +06m] plan - Assets/Scripts/Utilities/Assets/Editor/HumusAssetProcessor.cs only: preprocess opens enabled build scenes holding owner types and queues their prefabs before the flush; IProcessSceneWithReport stamps projectPath on the build scene copy; arrays handled in ApplyHumusAssetProcessor
[18:42:49 +08m] implemented - HumusAssetProcessor.cs: ScanBuildScenes (preprocess, before flush), OnProcessScene (stamps build scene copy, errors on unflushed targets), GroupByOwnerType extracted, ApplyHumusAssetProcessor handles HumusAsset arrays/lists
[18:44:37 +10m] compiled - clean (editor ready, ScanBuildScenes present in loaded assembly, 0 console errors)
[18:45:37 +11m] verifying - editor-side simulation via bridge (no /qa: build step, no play-mode scenario); opened each test level additively, ran ApplyToScene, compared stamped projectPath to the scene's own target, closed without saving
[18:50:00 +16m] stamping results - Falloff 34/34 (22 overrides, LootBox arrays), Parking 102/102 (90 overrides, Respawnable 87), Blockeria 32/32 (19), Crossy 12/12 (7), Red Arena 27/27, Take Over 2/2, Cage Test 53/53 (2), Cage Test 2 46/46 (MultiplayerSpawnEntity 2 overrides, e.g. MP Bomb Blast -> MP Bomb Turbo); Rocket Arena check did not run (bridge reply lost)
[18:52:00 +18m] ScanBuildScenes end-to-end with a no-op apply - 37 of 153 build scenes opened, 847 components matched, 185710ms; console errors only from scene content (missing Vendor prefabs, UDShadowCamera in edit mode); scenes closed, nothing saved
[18:53:02 +18m] done - PR file and result written: inconclusive (editor simulation passed, no player build)

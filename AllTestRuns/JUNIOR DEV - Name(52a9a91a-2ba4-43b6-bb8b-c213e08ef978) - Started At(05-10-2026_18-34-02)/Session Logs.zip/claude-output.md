I fixed the bug, but the result is **inconclusive**: no player build has been run yet. An editor-side simulation of the build step gives the right paths on all 8 levels I checked.

**Cause:** The build step writes `projectPath` (the path a player build loads the prefab from) only into prefabs and assets, never into scenes. So in a build, a scene object that swaps in a different prefab still has the path of the original prefab, while the editor spawns the swapped one. HumusAsset array fields (`ZoneSpawnOnCompletion`, `LootBox`) never got a path at all, even in prefabs, so they load nothing in a build.

**Fix** (only `Assets/Scripts/Utilities/Assets/Editor/HumusAssetProcessor.cs` changed):
- **Before the build:** it opens each enabled build scene that uses one of these components and queues their prefabs for the build's Resources copy. Scenes are closed without saving.
- **While the build processes each scene:** it writes the right path into the build's copy of the scene. It logs an error if a prefab wasn't queued earlier, because that would load nothing in the player.
- Array and list fields are now handled one element at a time.

**Verification:**
- **Compile:** clean.
- **Scene check:** I opened 8 affected test levels in the editor, ran the new step and compared each path with the prefab actually set in the scene. Every value matched, including the 142 that differ from the original prefab. For example:
  - Parking: 102/102, with 87 swapped `Respawnable` prefabs.
  - Cage Test 2: the `MultiplayerSpawnEntity` swap from MP Bomb Blast to MP Bomb Turbo.
- **Rocket Arena:** this check never returned, so that level is untested.
- **Full pre-build scan:** it opened 37 of the 153 enabled build scenes, matched 847 components and saved nothing.

**Things to know before merging:**
- **Build time:** the scene scan took about 3 minutes in this editor, added to every build.
- **Errors in the build log:** opening those scenes logs errors that were already there in the scene content (missing Vendor prefabs, `UDShadowCamera`). The build only fails on them with `useStrictMode`, which is off by default.
- **Still needed:** a build of Blockeria or Cage Test 2 to confirm the swapped prefabs spawn.

The PR description, result JSON and journal are written. No screenshots, since this was checked through editor output only.
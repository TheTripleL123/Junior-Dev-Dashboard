I fixed the stun bar on the Spiked and Armored Junkdogs and on the Jungledog variants, and checked it in the editor. Result: **pass**. The Turbo and Friendly Junkdogs on the report don't have this bug, and I couldn't find a separate cause for them.

**Cause:** Spiked and Armored dogs add a helper entity (`EntityProxy`) on the rib cage, pelvis or physics rig when they start, so hits land on the spikes or armor first. The health-bar UI sits under the rib cage and takes its stun value from the nearest entity above it. On these variants that's the helper, whose stun value always stays at 0. Stun damage still goes to the dog, so it gets stunned while its bar never moves. The base Junkdog, Bloodhound and base Jungledog have no helper, which is why they work. Every Jungledog you can spawn besides the base one is spiked or armored.

**Fix:** one change in `Assets/Scripts/Combat/UI/BotHealthBar.cs` (`Setup`). It now skips any entity that can't be stunned and binds the bar to the dog itself. This uses the same pattern as the health lookup right below it. The multiplayer bots' UI uses the same file; the change only skips entities that can never be stunned, so it should be safe there too.

**Editor check:** singleplayer, Quick Rampage, with the stun set from code.
- **Old binding confirmed:** on all four Spiked/Armored bots, the nearest stun source above the bar is the helper entity. After the fix, the bar reads the dog on all 9 bots I spawned.
- **Reported cases:** at 60% stun, the stun line fills on Junkdog Spiked, Junkdog Armored Left, Jungledog Spiked and Jungledog Armored Right.
- **Full stun:** the Spiked Junkdog and Spiked Jungledog both get stunned and show the stun icon and the duration line.
- **Regression:** the base Junkdog, Turbo, Bloodhound and base Jungledog bars still fill. The Friendly Junkdog was already stunned by other bots when I applied stun, so it showed the duration line instead of the 60% fill.
- **Evidence:** 22 screenshots. No game errors in the console; the only two were typos in my own test commands.

**Not fixed or not tested:**
- **Turbo and Friendly Junkdogs:** no cause found. Their bar already reads the dog itself, and the Turbo bar filled in the test. Turbo dogs take half stun damage, so their bar fills half as fast, which may look broken. Someone should recheck these by hand.
- **Rabid and Jingle Ball Junkdogs:** not spawned. Both use the base Junkdog prefab, which the report says works.
- **Turbo Spiked/Armored variants and Jungledog Armored (both):** not spawned. They have the same spikes or armor, so the fix should cover them, but this run didn't check.

The PR description is at `C:\Users\CloudMachineA\Desktop\Cloud Machine A\_work\_temp\PullRequest.txt` and the result is in `junior-dev-result.json`; the workflow commits and opens the PR.
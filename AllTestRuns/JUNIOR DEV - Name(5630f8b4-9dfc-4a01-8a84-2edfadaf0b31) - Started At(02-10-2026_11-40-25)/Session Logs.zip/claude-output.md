I fixed Stun Lock and tested it in the editor: stuns from the left-arm weapon and from the blast wave now set the enemy to Overheated, and the arm Stun Lock is on still works. The tests used simulated hits, not real gameplay.

**Root cause:** Stun Lock (`Addon - Stun Crashers.asset`, script `OverStun`) is an arm addon. It attached its Stun → Overheat damage converter to the arm it was equipped on. When an enemy's stun bar fills, the converter only runs if the hit that filled it came from that arm or that arm's weapon. So stuns from the other arm's weapon were never converted. Neither were blast-wave stuns from a weapon on that other arm, since a blast wave counts as coming from the weapon that fired it. The Jack face hit only worked because it happened to come from the arm Stun Lock was on.

**Fix (2 files):**
- `Assets/Scripts/Run/Items/Implementations/OverStun.cs`: new `applyToMech` option that puts the converter on the whole player mech instead of one arm.
- `Addon - Stun Crashers.asset`: `applyToMech: 1`. Over Stun uses the same script but keeps working per arm, and its stun-duration boost is still applied before the conversion.

**Verification:** in Play mode (singleplayer, Quick Rampage, 0 console errors), with Stun Lock on the right arm and two Junkdogs:
- **Left weapon hit:** the stun carried Overheat (1.5 s).
- **Blast wave:** I spawned one fired by the left weapon, using the Focused Blaster's blast-wave settings. The dog ended up stunned and overheated, and 21 screenshots show the overheat glow on it.
- **Right arm (where Stun Lock is):** still overheats.
- **Over Stun on the left arm:** still per arm; a 4.5 s stun gave a 4.5 s overheat.

**What wasn't tested:**
- The real Focused Blaster wasn't equipped. The blast wave was created directly from its settings, and the blaster's own firing code wasn't changed.
- All hits were simulated, since there's no VR here.
- I used a Junkdog instead of Jack; the stun-to-overheat code is the same for both.

I reverted three `.meta` files that the editor rewrote during import; they weren't part of the task.

Files are in `_work\_temp`:
- PR description: `PullRequest.txt`
- screenshots: `junior-dev-screenshots`

Files are in the repo root:
- `junior-dev-result.json`
- `junior-dev-progress.md`
I fixed it: Stun Lock now overheats bots that the player stuns by knocking them into a crash. I checked it in the editor and the result is **pass**.

**Cause:** a punch or a Focused Blaster blastwave rarely fills a bot's stun meter by itself. In the editor a blaster punch added 9 stun and a blastwave about 25–30, against a Junkdog meter of 50. What finishes the stun is the crash when the knocked-back bot lands. That crash stun was credited to the bot itself, so Stun Lock on the left arm never saw it: the bot got stunned but not overheated. A Jack hit in the face worked because that one hit fills the meter on its own.

**Fix:** one change in `Assets/Scripts/Combat/Entities/EntityBehaviours/DamageHandler.cs`. A crash stun is now credited to whoever launched or held the bot, which the crash code already records. It applies to every arm, not just the left. The file is shared with multiplayer, where a stun can already be credited to another player's mech, so this isn't a new case there.

**Checked in the editor** (left arm with Stun Lock and Focused Blaster, set up and hit from code):
- **Junkdog:** a weak punch plus a launch, so only the crash filled the meter. It was stunned and overheated: red body, smoke, both icons.
- **Jack:** filled by one big hit, stunned and overheated.
- **Regression:** a JungleDog stunned by a hit that didn't come from the player was stunned without overheat.
- 15 screenshots; the capture check passed.
- **Console:** two null-reference errors, both from my test punch being built from code without a collider. The punch code's debug log reads that collider's name, so they aren't caused by the fix.

**Not tested:**
- Jack stunned through a crash: the launch on Jack never produced a crash.
- The blastwave end to end after the fix. Its knockback crash goes through the same code as the Junkdog case.
- The right arm.
- Stuns from crashes of grabbed or thrown bots.

The PR description is in `_work/_temp/PullRequest.txt` and the result in `junior-dev-result.json`.
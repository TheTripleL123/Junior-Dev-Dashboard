I added the Rumble round log to the server module and tested it on a throwaway local database. The result is **inconclusive** because the tables don't sync to Snowflake yet: the `data-pipeline` repo isn't on this machine, so I couldn't register them in `data-pipeline/src/stdb_event_tables.py`.

**What it records**
- **`EventsDeathmatchRounds`:** one row per round, written once when the result is final.
  - Round id, room and map, start time, end time and length.
  - How it ended (`Won` / `RoomEmptied` / `Merged`), the winner and `killsToWin`.
  - Player count at start, at end and at peak.
  - Kills, deaths and bonus kills.
  - The bonus outcome and who killed the winner.
- **`EventsDeathmatchKills`:** one row per kill (the optional part): killer, victim, kill type, suicide flag, whether it was in the bonus round, and the time.
- **Pruning:** `PruneEventsHistory` now prunes both tables.
- **Running counts:** kept in a small private table while the round is in progress, and deleted with the room.
- **Client bindings:** regenerated (4 new type files, no client code uses them). The analytics guide lists the two new tables.

**Choices that change what the numbers mean** (all in the PR text so a reviewer can change them)
- A won round ends at the kill that reached `killsToWin`, so round length leaves out the 30 s winning round, matching the 3 to 5 min target.
- The server restarts a round's clock when a room reaches two players. The counts restart with it, so the player count at start is always 2 for a real round (1 for a lone room). I added a peak player count because of this.
- I didn't add columns to the existing `Deathmatch` table, because players already on released builds receive that table.

**Testing (throwaway local database `dmrounds-test`)**
I called the real deathmatch code through temporary test reducers, then removed them, deleted the database and stopped the server.

| Scenario | Result |
|---|---|
| Won round with a bonus round | One correct `Won` row |
| Room emptied mid-round | One correct `RoomEmptied` row |
| Lone player merged | One correct `Merged` row |
| Winner leaves during the bonus round | One correct `Won` row, bonus outcome "winner left" |

Deleting the room afterwards never added a second row. The kill rows came out right, and pruning ran over both tables. The module builds clean and Unity compiles with 0 errors.

**Not checked**
- How the Snowflake sync reads these tables (pg-wire). The local test server runs without that port and the Python driver isn't installed here. All columns use the same simple types as a table that already syncs.
- A real game session. This is a server-only change, so I tested it through the server code rather than by playing.

**To do**
- Add these two rows to `data-pipeline/src/stdb_event_tables.py` (also in the PR text):
  ```
  {"stdb": "EventsDeathmatchRounds", "sf": "STDB_EVENTS_DEATHMATCH_ROUNDS"},
  {"stdb": "EventsDeathmatchKills",  "sf": "STDB_EVENTS_DEATHMATCH_KILLS"},
  ```
- After review, someone publishes the module. A normal publish is enough; no `Migrate` is needed.
- Rounds already running at deploy can undercount kills in their first row.

Files are in the working tree for the workflow to commit; the PR description is at `_work/_temp/PullRequest.txt`.
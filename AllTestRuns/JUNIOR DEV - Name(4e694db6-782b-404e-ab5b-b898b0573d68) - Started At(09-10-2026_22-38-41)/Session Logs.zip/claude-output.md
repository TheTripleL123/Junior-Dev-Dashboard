I made all four HP balancing changes, but nothing has been checked in the game. The Unity editor was stuck on a "Recovering Scene Backups" popup and never became ready, so the result is **inconclusive**.

**Changes (four multiplayer assets, no code):**
1. **Proteza arm HP 85 → 70:** 85 × 0.7 → 60 (step 1), then 60 × 1.2 → 70 (step 3).
2. **Proteza bubble HP 55 → 30:** 55 × 0.7 → 40 (step 1), then 40 × 0.76 → 30 (step 3).
3. **Rumble health multiplier 0.65 → 0.93:** this is 0.65 ÷ 0.7, rounded. The deathmatch prefab's equip-upgrades component has no number of its own. It applies the "Rumble Half Health" upgrade to both arms and the cockpit, so I changed that upgrade.
4. **Cockpit hit damage in the matrix config:** ×1.5 → ×2, and the highest punch quality ×2.25 → ×3.

**Rumble will not stay at today's values.** Because step 3 comes after step 2, as the card orders, Rumble ends at about 65 arm / 28 bubble instead of today's 55 / 36. After steps 1 and 2 alone it was 56 / 37. Arms and cockpit share one upgrade, so no single multiplier can keep both at today's values. That would need separate arm and cockpit upgrades.

**Decisions to review:**
- "Base HP" is the health value on each Proteza item. There is no global multiplayer HP setting, and the 2026-09-30 pass (commit `0eb46e645a`) changed these same values. Bull, Graybox and King items are unchanged, as in that pass.
- I rounded the multiplier to 0.93 rather than to a multiple of 5, since it isn't an HP value.
- Commit `465a1bf121` named in the card does not exist in the repo.

**Still to do by hand:** check in a normal match that Proteza arm/bubble max HP is 70/30, about 65/28 in Rumble, and that cockpit hits do double damage.

**Not done:** making the Rumble multiplier survive a respawn. The card mentions it only as background, not as one of the four steps.

The PR description is at `_work/_temp/PullRequest.txt` and the result is in `junior-dev-result.json`.
I stopped without changing any code because I couldn't find a cause. No PR was opened.

- **Where the message lives:** the line is spelled "the jungle will kill you dead". It sits in the ACT I Intro cutscene (`Assets/_Tale/Run/Act I/Tale/Graphs/Cutscenes/ACT I Intro.asset`). A guard in that cutscene, `EntryGuard-46b0`, lets it play only on the first ACT I intro ever played on a save: it isn't reset per run or per slot. Those guard settings haven't changed since 2024.
- **Editor check:** I started a new run with the `Game Modes/Quick Tale` debug config on a brand-new save. The cutscene loaded and the message was on screen, so the "first time" path works. That shortcut skips the real menus, but the real path to a run uses the same run graph.
- **Other causes ruled out:**
  - The tutorial runs on its own graph (`Tutorial.asset`), so it can't use up the guard before the first real run.
  - The "skip cutscenes" tag is only set by a debug config.
  - The "skip seen cutscenes" setting only matters after the first time.
  - Nothing specific to Steam Frame touches the cutscene or save code.
- **Most likely explanation:** the Steam Frame install already had a save from earlier play, so the game skipped the message as designed. I couldn't confirm that without the device's save.

**Next steps:**
- Ask Nisan whether that install was brand new. If it was, get the device's `SaveGames` folder or the session log from that first run, and run a follow-up session on it.
- If the message should show on every new run or new slot, that's a design change, not a bug. Someone needs to say which, and then the guard can be changed.

The result (`aborted`, reason "cause not found") is in `junior-dev-result.json`, and the steps are in `junior-dev-progress.md`. The editor is out of Play mode.
title: Jungle Will Kill You Ded tip missing on first run
result: aborted
phase: done
updated: 10:26:12 (+16m)

[10:09:55 +00m] started - source branch master, task: 'The Jungle Will Kill You Ded' tip not shown in a new run on steam-frame
[10:20:30 +10m] oriented - singleplayer: card label SinglePlayer, text is in the SP ACT I Intro cutscene; job bug: card label Bug, reported as regression
[10:20:30 +10m] reported case - new SP run (first-ever per Omer) on steam-frame: the 'the jungle will kill you dead' text (ACT I Intro scene state 'Warning') is not shown; expected on first-ever run only. Gate: ACT I Intro.asset EntryGuard-46b0 (saveTo Game, Manually) -> ifFirstTime loads Warning + 12s wait, ifRest goes straight to Intro Skip. Graph unchanged since 2025-10; no STEAM_FRAME code on this path
[10:20:30 +10m] runtime check - question: on a fresh game save (Quick Tale), does EntryGuard-46b0 take ifFirstTime and does ACT I Intro load with state 'Warning'?
[10:23:40 +13m] runtime check answer - yes: scenes Main, Act 1 - Tale BG, ACT I Intro loaded; 'the jungle will kill you dead' TMP text under 'Warnings' active. Exited play. Quick Tale bypasses the real menus flow - asked context agent to trace the real first-launch path (tutorial -> SUS -> new run)
[10:25:50 +15m] cause not found - real flow: tutorial PlayRunNode uses its own Tutorial.asset graph (only _Run -> _ACT I Main -> ACT I Intro reach the guard), '@skip cutscenes' is debug-config only, graph_roundNumber has no runtime writer besides the run graph; guard settings unchanged since 2024. On a fresh Game save the text shows; most likely the device already had a Game save (guard is once per install by design). Not provable without the device's save file
[10:26:12 +16m] done - result aborted (cause not found), result JSON written, no PR file, no code changed

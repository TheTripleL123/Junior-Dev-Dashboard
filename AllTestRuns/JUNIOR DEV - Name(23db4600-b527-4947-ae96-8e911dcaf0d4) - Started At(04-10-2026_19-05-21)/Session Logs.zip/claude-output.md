I fixed the bug and checked it in the editor: the stun bar now fills on the spiked and armored junkdogs and jungledogs. Result is **pass**.

**Cause:** Spiked and armored dogs get a hidden helper object (`EntityProxy`) added to their back bones when they spawn. The stun bar sits under those bones and was reading its stun value from that helper, whose value is always 0. The dog itself still built up stun and got stunned, so the bar stayed empty while stuns still happened. Bloodhound's armor is on a different bone, which is why its bar worked.

**Fix:** a two-line change in `Assets/Scripts/Combat/UI/BotHealthBar.cs` (`Setup`). The bar now reads stun from the dog itself, using the existing `GameEntity.GetEntity` lookup that skips these helpers.

**Verification** (singleplayer, Quick Rampage, stun added from code):
- **Before the fix:** the armored and spiked bars read the helper and stayed at 0 while the dog had about 16 stun.
- **After the fix:** on the Spiked Junkdog and Jungledog, the Armored Both/Left/Right Junkdog, and the Armored Left/Right Jungledog, the bar matches the dog's stun. In screenshots the stun strip is about 76% full on the Spiked Junkdog and about 53% on the Jungledog Armored-Left.
- **Dogs that already worked:** base Junkdog, Bloodhound, base Jungledog and Turbo Junkdog are unchanged. Turbo shows half the stun because turbo halves stun damage.
- I took 27 screenshots. The only console errors are two "Could not find prefab" lines from my own attempts to spawn the Turbo Spiked and Turbo Armored junkdogs.

**Differences from the report and gaps:**
- Not every variant was broken. Before the fix, the plain Turbo Junkdog and the Friendly and XMas junkdogs already showed stun. Only the spiked and armored dogs were affected, including their Turbo versions.
- I couldn't spawn the Turbo Spiked and Turbo Armored dogs, because they have no spawn entry. They use the same spiked and armored setup and the same changed line, so they should be fixed too, but I didn't see it.
- Jungledog Armored (both sides) wasn't tested because its spawn entry doesn't work.
- The multiplayer health bar (`PlayerHealthBar.cs`) uses the same lookup. I didn't touch it because the task is singleplayer.

The PR description, result file and progress journal are written. The working tree contains only the change to `BotHealthBar.cs`.
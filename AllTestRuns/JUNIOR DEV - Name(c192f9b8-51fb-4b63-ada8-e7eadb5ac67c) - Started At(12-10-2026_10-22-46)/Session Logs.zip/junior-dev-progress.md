title: Joint camera freezes game 1s on first view
result: inconclusive
phase: done
updated: 10:38:53 (+15m)

[10:23:21 +00m] started - source branch master, task: game freezes ~1s the first time the player walks in front of the joint's camera
[10:23:21 +00m] earlier session - 68c5113e ended during orientation, no code; branch carries only an editor-rewritten EditorBuildSettings.asset path for Block.unity (scene moved on master, same guid) - unrelated, will revert
[10:26:51 +03m] oriented - multiplayer: card label PVP, the Joint photo booth (PhotoBoothClient) is MP code; job bug: card label Bug, a 1s freeze is existing behaviour going wrong
[10:26:51 +03m] history - e5ed473bd7 (Kfir, Sep 2) already put the booth Mirror Camera into Stage Warmup - Multiplayer via a WarmupCamera task; device QA on card 04a60fb0 said the hitch was not resolved, reverted Sep 3 (8e58c1aba8, 5c64a041d0). So "put it in the warmup scene" alone is known not to work
[10:28:29 +05m] reported case - Joint, local mech walks into the photo booth overlap volume facing the screen for the first time in the session -> ~1s freeze; later times no freeze. No session running, no photo taken
[10:29:43 +06m] cause - PhotoBoothClient.cs:240-247 + :288-291: the Mirror Camera GameObject (inactive in Joint.unity) is first activated when the mech enters the overlap volume with the screen in view, and LateUpdate then makes the first manual mirrorCamera.Render() of the Joint into Mirro RT - a one-time render setup cost (pipeline/variant creation for the Joint's materials into that target). Predicts: freeze only on first entry, none after - matches. Explains the failed warmup-scene fix: that camera rendered the warmup scene's objects, not the Joint's. Editor cannot reproduce the stall (D3D11, cached variants)
[10:29:43 +06m] plan - PhotoBoothClient.Start: activate the camera GameObject, Render() once into Mirro RT, restore its active state - at Joint scene load, while the scene is still faded out before the mech spawns. QA: no errors, Mirro RT rendered once at load, booth camera still turns on/off when the mech walks in/out
[10:31:14 +07m] implemented - PhotoBoothClient.cs: Start calls new RenderMirrorAtLoad (activate Mirror Camera GO, Render() once into Mirro RT, restore active state)
[10:31:14 +07m] compiled - clean (editor ready, 0 errors before and after)
[10:31:34 +08m] verifying - /qa with 17 min, configs Dev/No VR, Advanced/Multiplayer/PC Room Segregation, Multiplayer/Levels/Joint
[10:33:04 +09m] play - Joint loaded, mech spawned; booth Start ran: camera component disabled, Mirror Camera GO back to inactive
[10:33:04 +09m] check - RenderMirrorAtLoad invoked again (ClearRTOnDisable off for the sample): Mirro RT centre pixel 0,0,0,0 -> 0.027,0.024,0.008,1 (rendered), GO restored inactive, no errors
[10:36:16 +12m] scenario - mech head pinned in front of the screen: Mirror Camera GO active, IsMyMechInArea true; moved out of the volume: GO inactive. Facing away inside the volume kept it on (existing view gate under No VR, code unchanged)
[10:37:00 +13m] captures - 6 isolated-close, 6 regression-check, 5 non-isolated-wide; check-captures OK. Non-isolated shot with the mech in front shows the live mirror on the screen; after leaving, screen shows a cleared flat green. Isolated-close shots do not show the screen itself (the isolated canvas did not draw) - weak evidence
[10:37:00 +13m] console - only FMOD mic-driver errors (no mic on the cloud machine) and a Photon voice timeout after the pause; nothing from PhotoBooth/ClearRTOnDisable. Exited play
[10:37:36 +14m] reverted - ProjectSettings/EditorBuildSettings.asset back to master (unrelated editor rewrite from the earlier session)
[10:38:53 +15m] done - inconclusive (device-only stall); PR file and result written

I've made a fix, but I can't confirm it removes the freeze: the result is **inconclusive**. The 1-second freeze only happens on a headset, and the editor doesn't reproduce it.

**Why the warmup scene won't work:** that was already tried. Kfir's commit e5ed473bd7 on Sep 2 rendered the photo booth's mirror camera in `Stage Warmup - Multiplayer`. On card 04a60fb0, the device test said the freeze was still there, and the change was reverted on Sep 3. That camera renders the warmup scene's objects, not the Joint's, so the Joint's first render still pays the setup cost.

**Cause:** the first time your mech walks into the booth area with the screen in view, `PhotoBoothClient` turns on the mirror camera and makes its first render of the Joint into Mirro RT (`PhotoBoothClient.cs:240-247` and `:288-291`). That first render carries a one-time setup cost, which fits "only the first time." I didn't measure the exact cost on device.

**Fix (`PhotoBoothClient.cs`):** `Start` now calls a new `RenderMirrorAtLoad()`. It turns the camera on, renders the Joint once, and turns it off again. This happens while the Joint loads behind the fade, before the mech spawns, so the cost is paid there instead of at the booth.

**What I checked in the editor (Joint level):**
- After load, the camera is off again and the render had written into Mirro RT. To check this I ran the method again in Play mode and sampled a pixel.
- With the mech placed in front of the screen, the camera turns on and the screen shows the live mirror. When the mech leaves the area, it turns off.
- The only console errors were FMOD microphone errors (the machine has no mic) and a Photon voice timeout after pausing. Nothing came from the booth.
- 17 screenshots, but only the wide shots are useful. The isolated close shots don't show the screen, and the regression shots are framed far too wide.
- I didn't test a photo session or the `QuickCaptureRecorder` camera hold.

**Other notes:**
- The branch's earlier commit included an unrelated editor rewrite of `ProjectSettings/EditorBuildSettings.asset`. I put it back to master.
- With the mech facing away inside the booth area, the camera stayed on. That's the existing screen-in-view check, which this change doesn't touch.

**To confirm on a Quest:** clear app data, enter the Joint and walk up to the booth screen. There should be no freeze the first time. If a smaller hitch remains, the next suspect is mechs: no mech is in the camera's view when it renders at load. Taking a photo has its own first-use cost, separate from this report, and I didn't change it.

The PR description, result file and journal are written.
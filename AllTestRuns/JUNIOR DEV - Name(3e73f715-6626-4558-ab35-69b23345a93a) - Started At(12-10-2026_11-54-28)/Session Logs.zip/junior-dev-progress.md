title: Camera toolbox stays open across sandbox exit
result: pass
phase: done
updated: 12:16:30 (+21m)

[11:54:57 +00m] started - source branch master, task: camera toolbox persists into main menu / freezes game after leaving sandbox with it open
[11:57:36 +02m] oriented - singleplayer: card label SinglePlayer, sandbox; job bug: card label Bug, existing toolbox breaks across scene/mode change. Previous session b53073a2 not in index (CONVERSATION_NOT_FOUND), branch had no earlier commits - started from master
[11:57:36 +02m] reported case - SP sandbox play, toolbox open (paused, maximized). (1) exit to main menu -> toolbox stays and captures the main menu; should close. (2) press Edit -> toolbox lingers ~1s then hides; re-enter play -> game frozen, toolbox button gone, pause menu unpauses briefly; should be closed and game running
[12:01:51 +06m] cause - CinematicViewer.cs:485 OnCinematicViewerChanged: open state is only Settings._cinematicViewer, re-evaluated only by SyncToSettings on player mech start (CinematicControls.cs:765). The viewer lives on the playspace root and nothing closes it on a scene transition (main menu has no mech -> stays open) or on sandbox Edit (SandboxController.cs:675 sets _mode without a scene transition); re-entering play takes the non-fresh branch (_sessionActive still true) and restores pausedWhileMaximized -> paused, and CameraToolboxPauseMenu hides the open button because the setting is still true
[12:01:51 +06m] implemented - CinematicViewer.cs: close via Settings.SetCinematicViewer(false) on Primary non-WithinScene transition (SP only, PopupManager pattern) and in Update while SandboxController.isEditMode
[12:03:09 +08m] compile error - CS0103 ISceneLoader missing using (my edit); added using GameTeller.Graph
[12:04:20 +09m] compiled - clean
[12:04:29 +09m] verifying - /qa via subagent with 18 min, configs Dev/No VR, PC Room Segregation, Misc/Sandbox (Play), God
[12:15:38 +20m] captures - 6 isolated-close, 0 regression-check, 4 non-isolated-wide (check-captures OK): A toolbox open, timeScale 0; B Edit -> IsOpen false, setting false, no viewer timescale key; C Play -> closed, ShowButton true, only timescale holder SandboxPlayer low-FPS popup; D exit transition (reloads sandbox under config) -> IsOpen false. No CinematicViewer errors; play exited, lease released
[12:16:30 +21m] done - pass; PR file and result JSON written

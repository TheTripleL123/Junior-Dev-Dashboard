I fixed both sandbox problems, and the editor test passed. The camera toolbox now closes itself when you press Edit and when single player leaves a scene. The test did not load the real main menu, though, because the sandbox debug config reloads the sandbox on exit instead.

**Why it broke:** the toolbox stays alive for the whole session and only re-checks whether it should be open when a player mech spawns.
- **Main menu:** no mech spawns there, so nothing closed it.
- **Edit button:** switching sandbox to edit mode isn't a scene change, so nothing closed it then either. Back in play, it restored its saved "paused" state, which froze the game. The pause-menu button to open it stayed hidden because the toolbox setting was still on.

**The fix** is in `Assets/Scripts/Animation/Cinematic/CinematicViewer.cs`. In both cases the toolbox closes the same way its own close button does, which stops any recording and removes its pause:
- In single player it closes when a scene change starts. This follows the pattern the popup and pause menus already use. Multiplayer is left alone.
- It closes while sandbox is in edit mode, where it already couldn't be opened.

**Test results** (sandbox, no VR):
- **Open in play:** the game paused, as expected.
- **Press Edit:** the toolbox closed and was no longer pausing the game.
- **Back to Play:** it stayed closed, and the button to open it showed again.
  - The game was still paused at first, by sandbox's low-FPS warning popup that this slow machine triggers, not by the toolbox. After continuing past that popup, the game ran normally.
- **Exit:** reopened, then "exit to main menu". The toolbox closed during the scene change. The only console errors were from other systems, already present or during the exit transition.

**Not tested:**
- Exiting to the real main menu scene.
- That the toolbox stays open in sandbox play when nothing changes, and across a respawn. A respawn doesn't change scene, so the new close shouldn't run there.
- Multiplayer.

**Decision for review:** in single player the toolbox now also closes on any scene change, for example from the hub into a level, so a recording won't continue across a scene load. That check can be narrowed if a recording should carry over.

The previous session's notes weren't in the index and the branch had no earlier commits, so I started from master.

Files are in `_work`:
- `_temp\PullRequest.txt`
- `underdogs\junior-dev-result.json`
- `underdogs\junior-dev-progress.md`
- `_temp\junior-dev-screenshots`
title: Grips disabled after leaving play with cam tools open
result: aborted
phase: done
updated: 10:59:47 (+19m)

[10:40:45 +00m] started - source branch master, task: grips stay disabled after returning to Sandbox edit mode with the cam toolbox open; branch confirmed, only untracked junior-dev-full-process-debug.jsonl (workflow log)
[10:46:34 +05m] oriented - singleplayer: card label SinglePlayer, Sandbox edit/play; job bug: card labeled Bug, grips used to work
[10:46:34 +05m] reported case - Sandbox (user level), Play, open camera toolbox (CinematicViewer), pause menu Edit (SandboxPauseMenu.SandboxEdit -> ReloadAsync) -> in edit mode item grabbing (SandboxDraggable drag/duplicate/delete listeners) does not work, stays broken across Play/Edit; expected: grabbing works in edit mode | readings: (a) toolbox stays open in edit mode and its pause (PauseChangeEvent(true)) disables SandboxDraggable listeners; (b) a stale PauseChangeEvent(true) without matching false
[10:46:34 +05m] runtime check - question: after SandboxEdit reload with the toolbox open, is CinematicViewer.IsOpen() true in edit mode and are SandboxDraggable.dragAndDropListener disabled?
[10:59:47 +19m] runtime check answer - configs Dev/No VR, PC Room Segregation, Game Modes/Misc/Sandbox (Play), God; boot load hit a sharing violation on unnamed.sandbox, loaded play from code. Toolbox opened in play (timeScale 0). Variant 1 SandboxEdit reload: edit mode, toolbox closed (IsOpen false), timeScale 1, draggable listener enabled, last PauseChangeEvent false, no raycast filters. Variant 2 (play again, toolbox reopened, pause menu open, then SandboxEdit): same - toolbox closed, listener enabled, PauseMenu not paused. Reported case did not reproduce; readings (a)/(b) ruled out
[10:59:47 +19m] cause - not found. Grip = UDAction.Locomotion; code lead only: SP_Gorilloco.cs:311 drops grip while pilot.disableStickRotation is set, set by CinematicViewer.SetCameraSticksOverride (CinematicViewer.cs:1451) and SandboxEditor.LateUpdate (SandboxEditor.cs:393); flag is per mech so it cannot survive the reload - not explained, not confirmed. Aborting, no code changed

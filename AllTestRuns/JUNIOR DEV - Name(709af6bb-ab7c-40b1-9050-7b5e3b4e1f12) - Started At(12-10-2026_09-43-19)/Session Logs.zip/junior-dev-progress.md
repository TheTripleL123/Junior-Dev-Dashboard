title: Rampage error spam and SpawnHandle leak crash
result: pass
phase: done
updated: 09:58:57 (+15m)

[09:43:52 +00m] started - source branch master, task: reapply fix for Rampage memory crash (RendererPropertyBlock exception + index out of range spam, "SpawnHandle but still no bot" leak)
[09:46:43 +02m] oriented - singleplayer: card label SinglePlayer, Rampage; job bug: card labeled Bug, crash with error logs. Earlier session 3f0e7f7d (same RunID) passed with a 4-file fix that never got committed; branch has no commits past origin/master. Recap read; /game-context re-verified its claims in current source (BotGateBase sole IBotGate implementer, SpawnHandle equality by spawnID, null returns handled by callers, OnSpawned releases the temp bot cost, TryGetCache exists).
[09:46:43 +02m] reported case - Rampage 2H/5+ton session: "Getting an update for a SpawnHandle but still no bot!" x800, RendererPropertyBlock exception + index out of range x6600, then crash. Expected: no stuck spawn handles, no per-frame RPB exceptions.
[09:46:43 +02m] cause - LevelRunner.cs:983-984 SpawnBotThrottledAsync re-adds the handle with haveBot false when GetPreWarmedBot returns no bot after the dynamic spawn; BotGateBase.SpawnBehvaiour (:221-226) waits for every handle to have a bot, so the gate is blocked until ClearSpawns and the temporary bot cost is never released. RPB spam: already fixed on master by d3d45aa554c (not in build 12227); remaining unchecked indexers StartLerpMaterialSequence(int,..,List,List,float) and LerpMaterial hardened with TryGetCache | plan - reapply the earlier session's diff to IBotGate.cs, BotGateBase.cs, LevelRunner.cs, RendererPropertyBlock.cs
[09:47:11 +03m] implemented - IBotGate.cs + BotGateBase.cs: RemoveSpawn(SpawnHandle); LevelRunner.cs: on no bot after dynamic spawn, log error, remove the handle from the gate, release temp bot cost, return null; RendererPropertyBlock.cs: TryGetCache guard in StartLerpMaterialSequence(list overload) and LerpMaterial. +22/-4, same as the earlier session's diff. Editor ready, no preexisting compile errors.
[09:48:43 +04m] compiled - clean (0 errors)
[09:49:04 +05m] verifying - /qa with 22 min, configs Quick Rampage, Dont Spawn Enemies, God, No VR, PC Room Segregation
[09:50:41 +06m] play - Rampage scene ready
[09:51:29 +07m] reported case - Roach prewarm queue set to 2 destroyed GameObjects, SpawnBotThrottledAsync("Roach",0): Gate 1 pending True during the spawn, returned null, logged "Failed to spawn bot 'Roach' - removing its pending spawn from gate 'Gate 1'", no "still no bot!", Gate 1 pending back to False
[09:53:01 +09m] normal spawns - Roach 17 (queue) at Gate 1, Roach 19 (empty queue) at Gate 3, BomBot 9 at Gate 5, Junkdog 1 at Gate 6; all 7 gates pending False. A first try with the misspelled name "BomBot" threw NRE in BotGates.PrepareBotForInstantiationAsync:152 and left Gate 5 pending (the exception path, not covered by this fix); cleared it by hand
[09:54:07 +10m] captures - 7 isolated-close, 6 isolated-wide-regression-check, 6 non-isolated-wide, check-captures OK: close shots show each bot standing at its gate; the 6 regression wides framed on the gate and came out with the bot hidden (hidden=[...])
[09:57:38 +13m] regression - Rampage replay with waves on (Dont Spawn Enemies off): at 60 s all 7 gates pending False, no SpawnHandle/RPB/out-of-range/failed-spawn errors; 2 unrelated prop errors (Gas Balloon UnsafeKill, collision ignore pair)
[09:57:55 +14m] play exited, editor lease released; tree holds only the 4 task files
[09:58:57 +15m] done - PR file and result JSON written, result pass, 0 fix rounds

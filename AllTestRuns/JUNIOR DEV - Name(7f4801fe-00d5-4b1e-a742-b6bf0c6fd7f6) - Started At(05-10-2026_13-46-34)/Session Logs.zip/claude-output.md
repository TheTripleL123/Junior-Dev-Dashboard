Stun Lock now overheats enemies whose stun was filled by an indirect hit linked to its arm, like an enemy that arm threw or punched crashing into a wall. It worked in the editor and the result is **pass**, but the crash was sent from code rather than a real physics throw.

**What was wrong.** Stun Lock only converted a stun when a hit from its own arm filled the stun bar. The previous session confirmed direct left-arm punches and the Focused Blaster shockwave already convert.

**The fix.** The "in hindsight" link Amit mentioned already exists: when an enemy crashes, the game records which arm was holding it, or last hit or threw it. Z-Bang and the Blastwave props use the same link. The stun created on that crash was dropping it.
- `GameEntity.AddStunDamage` now copies that link onto the stun, and `DamageHandler` passes in the hit that filled the stun bar.
- `DamageModifier` has a new option, `outgoingConnectedEntityModifyType`, to also apply to linked hits. It is off by default, so other modifiers behave as before. It skips hits from its own arm, so a direct hit isn't converted twice.
- `OverStun.cs` passes the option through, and the Stun Lock asset (`Addon - Stun Crashers.asset`) turns it on for held, hit and thrown enemies.

**Editor test (Quick Rampage, Stun Lock on the left arm, four Junkdogs):**

| Case | Result |
|---|---|
| Crash stun on a dog last hit by the left arm | stunned and overheated, both 1.19 s |
| Same crash, last hit by the right arm (control) | stunned only |
| Direct left-arm punch filling the stun bar | stunned and overheated, both 1.19 s (converted once) |
| Crash with no arm linked | stunned only |

The record of which arm last hit each dog came from real punches. The capture check passed with 17 screenshots. The only console errors came from a dog I moved off the arena by hand during setup, unrelated to the change.

**Not covered:**
- Jack and the Focused Blaster shockwave weren't re-tested this session.
- Over Stun, the addon that lengthens stuns, uses the same script but isn't switched on. If it shares an arm with Stun Lock, linked stuns convert at their normal length; turning the same option on in its asset would fix that.
- The link credits whichever arm last hit or threw the enemy, even if something else hit it in between.

I wrote the PR description, result JSON and progress journal for the workflow, and reverted four Deathmatch UI files the editor's import had rewritten.
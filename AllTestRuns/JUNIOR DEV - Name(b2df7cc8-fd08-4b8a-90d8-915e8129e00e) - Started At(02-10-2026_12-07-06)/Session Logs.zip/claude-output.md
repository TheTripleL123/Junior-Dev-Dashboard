The stun bar now fills on the armored and spiked junkdog and jungledog variants, and they still get stunned when it's full. Result is **pass**: it compiles clean and I checked it in Play mode (23 min).

**Root cause:** `BotHealthBar.Setup` used `GetComponentInParent<IStunComponent>()` to find where to read stun from. That returns the nearest `GameEntity` above the bar, not necessarily the dog itself. On the affected variants, an `EntityProxy` gets added above the bar at runtime:
- **Armored variants** (Junkdog Armored, JungleDog Armored and their Left/Right/Turbo versions, plus Junkdog Pet): `ArmorEntity` adds it on `PhysicsRig`.
- **Spiked variants** (Junkdog Spiked, JungleDog Spiked, Turbo Spiked): `JunkDogSpikes` adds it on `RibCage`.

A proxy never holds stun, so the bar always read 0 while stun built up on the dog itself and stunned it as normal. Bloodhound works because its armor proxy is on the head, which isn't above the bar.

**Fix:** one change in `Assets/Scripts/Combat/UI/BotHealthBar.cs` (11 lines added). The stun lookup now skips any entity without status effects (such as a proxy) and moves up to the dog's root entity. It works the same way as the health lookup just below it. No prefab changes.

**Verification** (singleplayer, Quick Rampage), with 4 broken variants and 3 that already worked (base Junkdog, base JungleDog, Bloodhound):
- On all 4 broken variants, the old lookup returned the `EntityProxy`. With the fix, all 7 dogs read stun from the dog itself.
- With stun held at 60%, every bar showed exactly the dog's stun value, and it's visibly about 60% full in the screenshots.
- Filling the stun all the way stunned all 7 dogs, and the bar switched to the stun-duration display.
- No errors from `BotHealthBar` in the console.

**Limits:**
- I applied stun through the same call a hit makes (`GameEntity.AddStunDamage`), not by actually punching the dogs.
- I didn't spawn the Turbo, Pet or other Left/Right armored variants. They use the same proxy setup as the ones I tested.
- The debug action `Combat/Spawn/Jungledog/Armored Both` is broken (it can't find its prefab), so I tested JungleDog Armored Left instead. I didn't fix that action.

I put back three `.uicss.meta` files that the editor rewrote on import, so the working tree has only the one change.

Files are in `C:\Users\CloudMachineB\Desktop\Cloud Machine B\_work\`:
- `_temp\PullRequest.txt`
- `underdogs\underdogs\junior-dev-result.json`
- `underdogs\underdogs\junior-dev-progress.md`
- 27 screenshots in `_temp\junior-dev-screenshots`
Pause and slow motion in the Camera Toolbox work again in singleplayer. I tested in the editor by calling the toolbox's own methods from code; the VR controls weren't used because there's no headset on this machine. Result is **pass**.

**Cause:** with any singleplayer mech, the toolbox hit an error every frame before it got to the code that applies the time scale. It was trying to show the quick-capture recording marker on the mech OS, but only the multiplayer mech OS has one. Commit 8e3b93b792 removed the check that skipped a missing marker. Because the error happened every frame, pause, the slow-motion knob and the left-controller slow-mo button did nothing, whether or not a recording was running.

**Fix:**
- `CinematicViewer.cs:1421`: skip the marker when the mech OS has none.
- `MechOS.cs`: a tooltip saying the `recording` marker is optional.

**Checked in the Petting Zoo sandbox challenge, with enemies:**
- **Pause:** the time scale went to 0, and a Rabid Junkdog that had been running stayed in the same spot for over 3 s.
- **Slow motion:** with the knob at x0.5, the time scale was 0.5.
- **While recording:** pause also took the time scale to 0.
- **Console:** the toolbox error no longer appears; the remaining errors are unrelated to the toolbox.

I took 11 captures and the capture check passed.

**Left as is:**
- In built-in sandbox scenarios such as challenges, the slow-motion knob is still disabled on purpose. Only debug builds, the gym and user-made scenarios allow it. If Amit expected it to work in the challenge they tested, that rule needs a design decision. Pause isn't affected by it.
- `IsTimeScaleDisabled()` crashes when the sandbox has no scenario loaded. I only saw this after a scenario failed to load on this machine, so I didn't change it.

I reverted the files the editor rewrote, so only the two files above are changed. The journal, `junior-dev-result.json` and `PullRequest.txt` are written.
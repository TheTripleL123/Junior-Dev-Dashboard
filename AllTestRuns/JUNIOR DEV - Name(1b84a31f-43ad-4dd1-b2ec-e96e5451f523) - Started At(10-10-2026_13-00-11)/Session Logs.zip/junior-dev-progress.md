title: Rumble room player cap value and enforcement
result: inconclusive
phase: done
updated: 13:11:48 (+11m)

[13:00:38 +00m] started - source branch master, task: check Rumble room cap is 6 and enforced on every join path (fix if not)
[13:02:47 +02m] oriented - multiplayer: card says Rumble deathmatch room, server matchmaking in SpacetimeDB module; job feature: the cap value is a design change (8 -> 6), not broken behaviour
[13:03:30 +03m] criteria - Rumble (deathmatch group: Block, Shithole Rumble) rooms cap at 6 players; elevator join, late join, round-end transfer/merge and rejoin never put more than 6 in a room
[13:03:30 +03m] cause - matchmaking.rs:97: deathmatch LevelList defaultNumPlayers is 8 (overridable by Globals deathmatch_numPlayers); per-room cap Room.maxPlayers is checked by IsRoomSuitableForGroup, ResolveJoinRequest (reservations included), group formation and private-room joins
[13:04:20 +04m] decision - round-end transfer of a room bigger than the cap (rooms created at 8 before the change, or a Globals change): split it into groups of at most the cap, because CreateRoom would otherwise give a 6-cap room 7-8 reservations and every claim is refused
[13:04:20 +04m] plan - matchmaking.rs: defaultNumPlayers 8 -> 6 (keep the literal's shape for MultiplayerOfflineDB regex); TransferFinishedDeathmatch chunks players by the room cap. Verify with cargo build; no local STDB run (module publish is a human step)
[13:04:29 +04m] implemented - matchmaking.rs: deathmatch cap 6; TransferFinishedDeathmatch splits players into groups of at most the room cap
[13:05:54 +05m] compiled - cargo build wasm32 release clean (no C# changed, Unity compile not needed)
[13:08:50 +08m] verifying - local SpacetimeDB rumblecap-test with temporary probe: new deathmatch room cap=6; 8-player old room transferred as 6 + 2, all 8 claims Ok, extra join into the 6-room refused "Room is full"
[13:09:59 +09m] verifying - baseline rumblecap-base (old transfer code, cap 6): 8 reservations in one 6-cap room, all 8 claims refused - confirms the split is needed
[13:11:09 +10m] cleaned - probe removed, test databases deleted, final module rebuilt clean
[13:11:48 +11m] done - inconclusive: verified on local SpacetimeDB only; PR file and result written

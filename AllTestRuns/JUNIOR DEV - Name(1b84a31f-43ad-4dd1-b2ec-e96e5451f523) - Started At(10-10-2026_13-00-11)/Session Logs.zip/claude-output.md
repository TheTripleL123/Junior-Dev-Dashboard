The Rumble room cap was **8, not 6** — the questionnaire was right. I changed it to 6. The result is **inconclusive**: the fix was tested on a throwaway local SpacetimeDB but not in the game, and the server module still has to be published by someone.

**Where the cap is set:** only on the server, at `Cloud Code Projects/SpacetimeDB-Server-Rust/src/reducers/matchmaking.rs:97`, for the deathmatch levels `Block` and `Shithole Rumble`. The client never sends a cap. A per-environment Globals row, `deathmatch_numPlayers`, would override the code value if it is set. Private-key rooms were already capped at 6.

**Enforcement was already in place** on every path, because each room checks its own stored cap:
- **Elevator join and late join:** a full room is never picked, and the final seat claim also counts reserved seats.
- **Merge between rounds:** only 1-player rooms are merged away, and the target room must have space.
- **Rejoin after a disconnect:** the player's seat stays reserved and still counts against the cap, so they can't get in past it.

**One gap, now fixed:** at round end the whole room moved as one group. A room bigger than the cap went into a single smaller room, and then every player's seat claim was refused as full. That would hit rooms created at 8 before this change. Those players now go into rooms of at most 6.

**Tests on the local database:**
- A new Rumble room is created with a cap of 6.
- An 8-player room moves at round end as 6 + 2, and all 8 players get their seats.
- A 7th player is refused from a full room.
- With the old round-end code, the same 8 players went into one 6-seat room and all 8 were refused.

The temporary test code and databases are removed, and the module builds clean. There's no in-editor check or screenshots, because a 7-player Rumble can't be set up in the editor.

**For a person to do:**
- Check `deathmatch_numPlayers` on dev, staging and prod. If it's set, it overrides the 6.
- Publish the server module. Existing rooms keep a cap of 8 until they close or finish a round.
- Commit `591373b5` (Episode 01, 6 mechs per level) isn't in this clone, so I couldn't compare against it.
- I didn't check whether the Rumble scenes have at least 6 spawn elevators.

The PR description is in `_work/_temp/PullRequest.txt`, and the result is in `junior-dev-result.json`.
title: Joint camera freezes game first time player walks past
result: inconclusive
phase: started
updated: 12:58:56 (+00m)

[12:58:56 +00m] started - source branch master, task: game freezes ~1s the first time the player walks in front of the Joint's camera; move it into the warmup scene

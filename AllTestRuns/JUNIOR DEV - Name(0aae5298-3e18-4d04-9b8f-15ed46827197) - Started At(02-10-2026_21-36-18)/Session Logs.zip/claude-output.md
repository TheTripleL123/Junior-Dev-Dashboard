I fixed the stun bar on the Spiked and Armored Junkdog/JungleDog variants and verified it in the editor (result: **pass**). I didn't spawn the other variants, and plain Turbo Junkdog may have a different cause.

**Root cause:** each enemy's health bar UI (`BotHealthBar`) picks where to read stun from with `GetComponentInParent<IStunComponent>()` in `Setup()`. On the variants, the bar's parent object `PhysicsRig/RibCage` carries an `EntityProxy`, so the bar was reading the proxy instead of the dog. The proxy has no status effects, so its stun is always 0. Stun still built up on the dog itself and stunned it, but nothing showed on the bar. I confirmed this in play on JungleDog - Spiked before writing the fix: the bar was bound to the proxy while the dog had 10/70 stun. The base Junkdog, base JungleDog and Turbo Junkdog were bound to the dog itself.

**Fix:** one condition in `Assets/Scripts/Combat/UI/BotHealthBar.cs`. If the nearest stun source is an entity without status effects, the bar uses the dog's root entity instead. The code already did this when no stun source was found. Entities that do have status effects are picked as before.

**Verification** (Quick Rampage, singleplayer): I spawned JungleDog-Spiked, Junkdog-Spiked, Junkdog-Armored Both and the base Junkdog, and added stun to each directly with `AddStunDamage`, the same method a weapon hit calls.
- All four bars now read the dog's own stun, and the bar value matches it.
- 12 screenshots show the stun bars partly filled, including the base Junkdog, which still behaves as before. Two blank framing attempts named `iso-close-*-0.png` are also in the folder; ignore them.
- Console has 0 errors.
- Play mode is exited, and I reverted three `.meta` files that the editor's import had rewritten.

**Not covered:**
- I only saw the broken state before the fix on JungleDog - Spiked. I didn't spawn the Friendly, XMas, Pet, Rabid, Jingle Ball, JungleDog Armored or Turbo Spiked/Armored variants. They run the same setup code, so the fix applies to any whose `RibCage` has the proxy.
- Plain Turbo Junkdog was already reading the right entity before the fix. If it still shows the symptom, the cause is something else; one candidate is that turbo halves incoming stun and the bar drains over about 3 seconds.
- I didn't find which code adds the `EntityProxy` to the variants. The fix doesn't depend on it.

Files are in `C:\Users\CloudMachineA\Desktop\Cloud Machine A\_work\`:
- underdogs\underdogs\junior-dev-result.json
- underdogs\underdogs\junior-dev-progress.md
- _temp\PullRequest.txt
- _temp\junior-dev-screenshots\
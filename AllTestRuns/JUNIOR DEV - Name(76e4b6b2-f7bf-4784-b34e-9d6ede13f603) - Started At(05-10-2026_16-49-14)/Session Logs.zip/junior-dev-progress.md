title: No lyrics music button still plays songs with lyrics
result: inconclusive
phase: done
updated: 16:57:53 (+08m)

[16:49:37 +00m] started - source branch master, task: 'no lyrics' button does not work - still get songs with lyrics
[16:51:52 +02m] reported case - Mute Lyrics settings toggle on; music still plays with vocals; expected vocals silent on every track. Readings: (a) vocals never mute, (b) vocals mute on the current track but come back on later tracks
[16:51:52 +02m] oriented - shared (SP+MP) music system: MusicManager_Impl is used in both modes. Cause in AudioPlaylistHandler.PlayCurrentSound + MusicManager_Impl.ApplyEventParams: the Vocal param is set on the playing FMOD instance only; a new instance (next playlist track, Skip, streaming-mode restart, unmute Resume) gets only perpetual params (FadeOutTime), so Vocal is back at its FMOD default. MusicManager_Impl.Update re-applies every frame only under UNITY_EDITOR, so builds show lyrics from the next track on. Predicts reading (b) in builds - matches "I still get songs with lyrics"
[16:52:16 +02m] implemented - AudioPlaylistHandler.cs: SetPerpetualParam (records the value for every new track + sets it on the current one), on IAudioPlaylistHandler and the mock; MusicManager_Impl.ApplyEventParams uses it for Volume and Vocal
[16:52:16 +02m] editor - ready, no compile errors before the change, no safe mode
[16:53:19 +03m] compiled - clean
[16:55:18 +05m] verifying - /qa, singleplayer, configs Dev/No VR, PC Room Segregation, Quick Rampage, Dont Spawn Enemies, God; play ready, Combat music playing, Vocal=1 on instance 2
[16:57:02 +07m] checks - MusicManager_Impl disabled (stops its editor-only per-frame re-apply). Muted: Skip -> instance 12 Vocal=0; streaming-mode restart -> instance 15 Vocal=0. Unmuted: current instance 12 Vocal=1, Skip -> instance 13 Vocal=1. Volume=1 on all. Console 0 errors. Settings restored, play exited
[16:57:16 +07m] captures - none: the state is audio (an FMOD param value), nothing visual to capture; evidence is the instance param reads
[16:57:16 +07m] cleanup - reverted 6 .uicss.meta files rewritten by the editor import
[16:57:53 +08m] done - inconclusive (values verified, no audible/visual check possible); PR file and result written

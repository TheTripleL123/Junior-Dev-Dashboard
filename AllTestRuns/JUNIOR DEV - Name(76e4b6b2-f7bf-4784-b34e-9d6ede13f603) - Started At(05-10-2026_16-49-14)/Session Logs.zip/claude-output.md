I've fixed the "no lyrics" button. I'm reporting it as **inconclusive** only because nobody has listened to it yet: the cloud machine has no sound output and audio can't show in screenshots. The FMOD vocal values I read in play show the fix working.

**Cause:** the button set the FMOD `Vocal` param to 0 only on the song playing at that moment. Every new song starts a new instance with vocals back at their default. That happens on the next track, on a skip, and when streamer mode changes. The bug didn't show in the editor because `MusicManager_Impl.Update` re-applies the setting every frame, but only in editor code.

**Fix:**
- `AudioPlaylistHandler.cs`: added `SetPerpetualParam`, which sets a param on the current song and on every song the playlist starts after it.
- `MusicManager_Impl.ApplyEventParams`: now uses it for `Vocal` and `Volume`. `Volume` had the same flaw, so music volume now also stays the same across tracks.
- This is the music system shared by singleplayer and multiplayer, so the fix covers both.

**What I checked in play** (Quick Rampage, with the editor-only re-apply switched off so the editor behaves like a build):
- **Lyrics muted, then skip:** the new song has `Vocal=0`.
- **Lyrics muted, then a streamer-mode restart:** the new song has `Vocal=0`.
- **Lyrics un-muted:** the current song and the next one after a skip both have `Vocal=1`.
- **Other:** `Volume=1` on every song, music kept playing after each skip and restart, and the console showed no errors. The project compiles clean.
- **Not checked:** a song ending on its own. That goes through the same code path as skip, but I didn't wait for one.

**Next step:** listen on a build. Turn on No Lyrics, skip a few songs, let one end on its own, and check every song stays instrumental.

I put back the mute-lyrics and streamer-mode settings I changed during the test. I also reverted 6 `.uicss.meta` files the editor rewrote on import, so the change is just the two files above. The PR description, result JSON and progress journal are written.
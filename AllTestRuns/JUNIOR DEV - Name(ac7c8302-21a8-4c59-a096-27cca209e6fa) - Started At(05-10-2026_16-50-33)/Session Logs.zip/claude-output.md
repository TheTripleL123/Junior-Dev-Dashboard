ICBTH and Bloody Mess no longer stop Rumble Crackers: with the fix, a ground slam puts the arm into Turbo with either addon on the same arm. I checked this in play mode and the result is **pass**.

**Cause:** the ICBTH and Bloody Mess part prefabs each marked every outgoing hit from their arm with tag value `6`. When Bloody Mess was made (d844d499a9), 6 meant `InteractionTag.BloodyMess`. A week later 2231a16472 replaced that enum entry with `GarageInteraction`, so the saved 6 silently changed meaning. ICBTH's prefab was copied from Bloody Mess and inherited it. Since then, every hit from an arm holding either addon has counted as a garage-preview hit. `RumbleCrackers.cs:24` ignores those, so it never fired. The same check also turned off Overdrivers, Turbo Defense System, and the Hot, Stun and Precision Engineering quirks on that arm.

**Fix:** I removed the leftover tag component from `ICBTH.prefab` and `BloodyMess.prefab`. Nothing else uses those prefabs, and nothing in the code still reads a "BloodyMess" tag.

**Verification** (Quick Rampage, setup done from code):
- **Fixed case:** with Rumble Crackers + Bloody Mess on the left arm and Rumble Crackers + ICBTH on the right, a ground hit put both arms into Turbo (PWR 3→4, blue Turbo glow). A second play session gave the same result.
- **Cause check:** I put the old garage tag back on the left arm at runtime only. The bug came back on that arm alone, while the right arm still went Turbo.
- 19 captures; the capture check printed `OK`.
- The scenario logged no console errors. One retry ran its setup before the scene had loaded and logged 4 "There is no mech" errors; that was my timing, not the change.
- Unity's import rewrote six unrelated `.uicss.meta` files; I reverted them, so the tree holds only the two prefabs.

**Not done:**
- I didn't test that Bloody Mess's gore explosion still triggers on killing blows. Its code doesn't read the removed tag.
- I didn't fix a separate ICBTH bug: `ICBTH.cs` declares `remoteEntityFlag` instead of overriding `connectedEntityModifyType`, so its explosion probably never fires. It's unrelated to Rumble Crackers and fixing it changes ICBTH's gameplay, so it needs a separate decision.
- I didn't look into the related item ID `{67a16041-…}` from the card thread.

The PR description is at `_work/_temp/PullRequest.txt` and the result JSON at `junior-dev-result.json`.
I fixed Stun Lock: it now overheats bots that get stunned by crashing after a left-arm hit, throw or hold, and bots stunned by the Focused Blaster shot. I tested it in the editor in singleplayer and the result is **pass**.

**Cause:** Stun Lock only worked when the hit that finished filling a bot's stun meter came straight from the arm, like a Jack face hit. Usually the meter fills when the bot crashes after being knocked back, and that crash counts as the bot's own, so Stun Lock ignored it. The crash already records the player as the one responsible (`connectedModifyingEntity`: last hitter, thrower or holder), but the stun created from it dropped that record.

**Fix:** this uses the existing "in hindsight" mechanism Amit mentioned:
- **`GameEntity.AddStunDamage` and `DamageHandler`:** the stun now keeps the player credit from the hit that filled the meter.
- **`DamageModifier`:** new opt-in field `connectedModifyingEntityTypes`. It defaults to `None`, so other users of `DamageModifier` don't change. When set, the modifier also applies to stuns credited to its arm, and it skips hits it already handled directly so nothing is applied twice.
- **`OverStun.cs`:** passes the new field to the modifier it adds.
- **`Addon - Stun Crashers.asset`:** field set to All.

**Test results** (Junkdogs, set up from code, Stun Lock and Focused Blaster on the left arm):
- **Crash credited to the left arm:** stunned and overheated, overheat lasting as long as the stun.
- **Same crash credited to the right arm:** stunned only, as expected.
- **Focused Blaster shot:** stunned and overheated.
- **Direct left-arm hit:** still overheats as before.
- **With Over Stun also on the arm:** a direct hit gives a 4.5 s stun with equal overheat, a crash gives 1.5 s with equal overheat.

There are 17 screenshots and `check-captures` printed OK. The second play session had no console errors; the first one's errors all came from my test setup.

**Not done:**
- **Jack:** not tested. The face hit is a direct hit, which the direct-hit test covers.
- **Over Stun:** its ×3 stun duration still applies only when the arm's own hit fills the meter. Setting the same field on `Addon - Over Stun.asset` would extend crash stuns too; that's a balance call for you.
- **Multiplayer:** not tested. The stun change is in code multiplayer also runs. I read the other handlers that act on credited interactions, and none of them react to a stun.
- **Previous session:** its summary wasn't available yet, and the branch had no earlier commits, so I started from the code.

I reverted four multiplayer UI files the editor rewrote on import. The PR description is at `_work/_temp/PullRequest.txt`, the result at `junior-dev-result.json`, and the journal in `junior-dev-progress.md`. The journal entry for the test steps was written once at the end, so its timestamp is later than when the steps ran.
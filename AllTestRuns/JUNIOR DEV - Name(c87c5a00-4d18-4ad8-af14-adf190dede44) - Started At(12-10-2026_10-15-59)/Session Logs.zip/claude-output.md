I fixed it: when a player's Normcore room connection is lost, the game now reconnects them to the same room and respawns their mech. If reconnecting fails, it takes them out of the STDB room and restarts the game flow instead of leaving them stuck. The run is marked **pass**, but the actual trigger, a real network drop, couldn't be reproduced in the editor (details below). I couldn't open log GKLH from this machine, so the cause comes from reading the code.

**Cause**
- Nothing in the project ever reconnected Normcore. `MultiplayerScene.DidDisconnectFromRoom` only raised an event.
- The only code that took a player out of the STDB room on Normcore loss was `MultiplayerConnectionMonitor`'s 10-second quit. It only starts watching after the first successful connect. So if the room failed to connect when the level opened, nothing removed the player from the STDB room and they had to restart. That connect error wasn't handled either.

**Changes** (2 files)
- `MultiplayerScene.cs`: after any disconnect the client didn't ask for itself (so the paintshop room switch and scene unloads are left alone), it retries up to 3 times with a growing delay and a 15-second limit per attempt. A failed first connect goes through the same retries. If all attempts fail, it raises a new `OnReconnectFailed` event. This file is under `_Tech/Scripts/Core/`, which counts as shared code, so the PR flags it.
- `MultiplayerConnectionMonitor.cs`: `OnReconnectFailed` runs the existing quit, which leaves the STDB room, shows the "connection lost" popup and restarts. Its 10-second timer is paused while a reconnect is running.

**Verification** (Joint level)
- **Reconnect:** I disconnected the room from code, then triggered the reconnect directly. It succeeded on the first attempt, back in the same room with a new mech, and worked again on a second run.
- **Local disconnect:** a disconnect the client asks for itself did not start a reconnect.
- **Giving up:** it reached the quit step. The editor skips the actual quit on purpose, so I only saw the "would quit" warning.
- **Fix round:** the first test showed a 5-second "no spawn assignment" error before the mech respawned. I fixed it by requesting a spawn elevator before each attempt, the same call the death respawn makes. The re-test had no spawn error.
- **Console:** the only remaining errors are microphone errors, because this machine has no mic.

**Not verified**
- The detection of an unexpected disconnect was only checked by reading the code. The run triggered the reconnect directly rather than through a real drop.
- A failed first connect wasn't run.
- The full quit in a build (leave, popup, restart) wasn't seen end to end.
- Reconnecting in the middle of an arena match wasn't tested.

The PR description, result JSON and journal are written. The working tree holds only the two changed files.
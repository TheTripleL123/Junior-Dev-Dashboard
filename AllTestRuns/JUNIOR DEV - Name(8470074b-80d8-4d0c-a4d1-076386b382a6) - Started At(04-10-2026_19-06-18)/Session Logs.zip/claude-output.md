I found the cause and made a one-file fix, but it's only partly verified, so the result is **inconclusive**. The blast-wave case works now; punches, the Jack face hit and other enemies weren't re-tested.

**Cause:** Stun Lock does overheat the stunned enemy. The problem is that the two timers don't run the same way:
- A bot's stun timer pauses while the bot is in the air.
- The overheat timer kept counting down.

A punch or the Focused Blaster's blast wave throws the bot into the air, so the overheat ran out mid-air while the stun still had about 1 s left. The bot then looked stunned but not overheated. A face hit doesn't throw Jack into the air, which is why only Jack looked right.

**Left arm:** the side plays no part. The addon is set up the same way on both arms, and on the left arm it correctly turned the stun into overheat. "Left arm socket" is most likely just where the tester equipped it.

**Fix:** in `GameEntity.PropagateStatusEffects` (`Assets/Scripts/Combat/General/GameEntity/GameEntity.cs`), the overheat countdown now pauses whenever a stun's countdown is paused. Overheat that comes with a stun now lasts exactly as long as the stun. It compiles clean.

**Side effect to review:** this applies to all overheat, not just Stun Lock's. Overheat from other sources will also last longer on a stunned bot in the air. If that's not acceptable, the pause needs to be limited to Stun Lock.

**Verification** (in the editor, set up from code: Stun Lock and Focused Blaster on the left arm, a Junkdog held in place):
- **Before the fix:** with 1.01 s of stun left, the Junkdog was in the air and no longer overheated.
- **After the fix:** it stayed overheated in the air (1.38 s of stun left) and after landing (1.18 s left). The captures show its red overheat outline mid-air.
- **Not seen:** the stun and overheat ending together. The Junkdog died first, and the regression check was skipped because the time ran out.

The console had one error that isn't from this change (`UnsafeKill … Gas Balloon Prop`).

The workflow will open a draft PR from the description I wrote.

Files are in `C:\Users\CloudMachineB\Desktop\Cloud Machine B\_work`:
- `_temp\PullRequest.txt`
- `underdogs\underdogs\junior-dev-result.json`
- `underdogs\underdogs\junior-dev-progress.md`
- `_temp\junior-dev-screenshots\` (10 captures)
title: Stun Lock overheat fails in left arm socket
result: inconclusive
phase: done
updated: 11:39:40 (+21m)

[11:17:54 +00m] started - source branch master, task: Stun Lock (stunned = overheated) does not work in left arm socket; only Jacks hit in face overheat; same for Focused Blaster blast wave
[11:18:10 +00m] branch - Automations/ClaudeJuniorDev/d442db34-..., clean (untracked workflow debug jsonl only), no earlier session commits
[11:26:30 +08m] oriented - singleplayer: no "multiplayer" in report; Stun Lock = OverStun addon (Addon - Stun Crashers.asset) adding an outgoing Stun->Overheat DamageModifier to the arm (DamageModifier.cs, GameEntity.AddStunDamage). Reported case: Stun Lock on ArmLeft; left-arm punch (and Focused Blaster blastwave on left arm) fills an enemy's stun buffer; expected stun + overheat; seen stun without overheat; works only for Jack hit in the face. Code reading did not show a cause (source check IsChildOf passes for arm/effector sources).
[11:27:34 +09m] runtime check - question: with Stun Lock on ArmLeft and left-arm punches on a Junkdog body vs a Jack head, which interaction fills the stun buffer (source entity/behaviour), and does the resulting stun interaction carry Overheat when applied (AboutToApplyInteractionEvent log)?
[11:29:21 +11m] play - Quick Rampage ready (No VR, PC Room Segregation, Dont Spawn Enemies, God); Stun Lock on ArmLeft, Jack + Junkdog spawned, interaction logger subscribed
[11:34:18 +16m] runtime check - left-arm hits that fill the buffer give stun + overheat: Jack body (Baton punches), Jack head (Focused Blaster shockwave, Stun 500 in one hit), Junkdog body - all isOverheated=True
[11:38:04 +20m] runtime check - answer: Junkdog hit 2x left + 1x right (right fills the buffer) -> stunned=True, overheated=False; stun interaction source = Effector - Baton - Default_Right, no Overheat added. Also saw CrashBehaviour (Car 1 - Red) adding stun to knocked-back bots. Cause: GameEntity.AddStunDamage (GameEntity.cs:870) sources the stun interaction from only the hit that filled the buffer, and DamageModifier.ModifyOutgoingInteraction (DamageModifier.cs:64) converts only when that source is under the Stun Lock arm. Exited play.
[11:39:40 +21m] decided - no code change: the fix needs a design decision on which stuns count for Stun Lock (any contribution from its arm / any player stun / only last hit) and touches core GameEntity stun code shared by all entities and by stun-duration items (Over Stun ordering). Reverted 3 import-touched .uicss.meta files. No PR file.

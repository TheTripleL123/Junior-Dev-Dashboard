I fixed the stun bar on the Spiked and Armored Junkdog and Jungledog variants and checked it in the editor (result: **pass**). The change is in `Assets/Scripts/Combat/UI/BotHealthBar.cs`.

**Cause:** the stun bar takes its stun value from the nearest game entity above it in the hierarchy. On Spiked and Armored dogs, the spikes and armor add an `EntityProxy` on the bones above the bar at runtime. So the bar read the proxy's stun, which stays at 0, while the dog's real stun buffer kept filling and stunned it. Bloodhound's armor only covers the head, so its bar was fine.

- **Before the fix:** I checked this live. The Spiked bar was reading `EntityProxy@RibCage` and the Armored bar `EntityProxy@PhysicsRig`, both stuck at 0. After one punch, the dog itself was at 4.4/50.
- **Fix:** when `BotHealthBar.Setup` picks where to read stun from, it now skips entities with no status effects and falls back to the dog itself. The health bar already does the same thing a few lines below.

**Verification** (Quick Rampage, enemies spawned and hit from code):
- After the fix, all nine dogs I tested read stun from the dog itself: Junkdog Spiked, Armored, Armored Left, Jungledog Spiked, Armored Left, plus base Junkdog, Bloodhound, base Jungledog and Turbo Junkdog.
- After a 20-damage punch, the stun line fills from the right. I looked at the screenshots for Junkdog Spiked, Junkdog Armored and Jungledog Spiked; the other two broken variants show the same stun values.
- After an 80-damage punch they all got stunned. On Junkdog Armored the stun icon showed and the line turned light blue and drained.
- Base Junkdog and Bloodhound still fill and stun normally.
- I took 30 screenshots (the capture check passed) and looked at five of them closely; the rest are captioned as not reviewed one by one.
- The only console error came from my own inspection script, not from game code.

**Not covered:**
- **Plain Turbo variants, Friendly, Rabid, Jingle Ball:** the report includes these, but they have no spikes or armor, so this fix doesn't touch them. Plain Turbo Junkdog was already reading the right value before the fix. Its stun fills at half rate and drains at 30/s, so the line can look like it isn't moving.
- **Turbo Spiked and Turbo Armored:** not spawned, but they get their spikes and armor the same way, so the fix should cover them.
- **Turbo JungleDog:** couldn't be spawned; its config name returned null.
- **Multiplayer bots:** they use the same bar but weren't tested.

The editor import had rewritten three unrelated `.meta` files, so I reverted them. The working tree now holds only the fix, plus the journal, the result JSON and the workflow's untracked debug log. The PR description is in `_work/_temp/PullRequest.txt`.
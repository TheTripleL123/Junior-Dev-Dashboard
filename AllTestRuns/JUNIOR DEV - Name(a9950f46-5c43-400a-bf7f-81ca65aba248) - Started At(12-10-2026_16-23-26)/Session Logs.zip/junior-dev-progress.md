title: No automatic reports sent during staging playtest
result: pass
phase: done
updated: 16:39:14 (+15m)

[16:23:52 +00m] started - source branch master, task: no auto-reports during playtest; staging used to send reports automatically
[16:28:45 +04m] oriented - multiplayer: playtests are Rumble (FFA deathmatch) matches, card hint "checkpoints might not be good for rumble"; job bug: auto-reports "used to" be sent and no longer are
[16:28:45 +04m] reported case - staging player build, playtest of Rumble rounds: no ReportSource.Auto reports arrive; expected one per checkpoint as before (SP restart/combat aftermath, Ball Tag round end still work) | criteria - a Deathmatch round end calls ReportUtility.TryAutoReportInBackground
[16:28:45 +04m] cause - Assets/__Multiplayer/_Tech/Scripts/LevelLogic/Deathmatch/DeathmatchController.cs:240: Active->Resetting round end has no auto-report call; only GameManager.Restart, RunController CombatAftermath and BallTagManagerClient.EndRound:164 call it, gate ReportUtility.cs:547 (!isProduction && !isEditor) unchanged | plan - add the call there like BallTag; QA: editor gate blocks the send, so verify by code path + compile
[16:29:06 +05m] editor - ready, no compile errors before the edit
[16:29:56 +06m] implemented - DeathmatchController.cs: HandleStateChanged Active->Resetting calls ReportUtility.TryAutoReportInBackground (first compile failed: missing using OneHumus.Logging, added)
[16:30:59 +07m] compiled - clean
[16:31:20 +07m] verifying - /qa with 22 min, plan: Shithole Rumble on a local SpacetimeDB, end the round with Dev_DeathmatchResult, trace TryAutoReportInBackground
[16:33:10 +09m] play - scene Shithole Rumble ready on dev STDB (no local STDB: no server change needed, round end driven by invoking HandleStateChanged with Active->Resetting copies of the live row), configs Dev/No VR, PC Room Segregation, Multiplayer/Levels/Shithole
[16:37:02 +13m] trace - Active->Resetting: 1 hit ReportUtility.TryAutoReportInBackground <- DeathmatchController.HandleStateChanged; Resetting->Active restart: 0 hits, no new console errors (only pre-existing FMOD mic / DMGFX errors from 16:33)
[16:38:06 +14m] captures - 4 isolated-close, 3 regression-check, 4 non-isolated-wide: local mech in Shithole after the synthetic round end/restart, scene intact; check-captures OK (no-face declared, change is not visual)
[16:38:23 +14m] exited play, trace rule removed, configs disabled, control released
[16:39:14 +15m] done - PR file and result written, result pass

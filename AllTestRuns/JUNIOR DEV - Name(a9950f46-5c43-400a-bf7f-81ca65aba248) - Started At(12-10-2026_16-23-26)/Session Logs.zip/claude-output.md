The playtests got no automatic reports because Rumble matches never reach a point that sends one. I added that point at the end of every Rumble round. In the editor the new call runs once at a round end; the upload itself hasn't been seen yet, because the editor skips it on purpose.

**Why it stopped:** staging and development builds send a silent report only at three fixed points (the "checkpoints" Omer meant):
- a single-player restart,
- after a single-player fight,
- the end of a Ball Tag round.

Rumble rounds hit none of them, so a playtest of only Rumble matches sends nothing. Nobody removed anything: the old reports came from single-player and Ball Tag, which these playtests don't go through. The check that decides which builds send reports hasn't changed.

**Fix:** `DeathmatchController.HandleStateChanged` now calls `ReportUtility.TryAutoReportInBackground()` when a round goes from Active to Resetting. It runs on every client, the same way Ball Tag's `EndRound` does. That means one report per Rumble round per player, the same rate as Ball Tag.

**Testing:** it compiles cleanly and was tested in Shithole Rumble in the editor.
- **Round end:** a real one needs 10 kills or a server dev command, and I can't run that command on the shared dev database. So I called the round-end handler directly with copies of the live round data (one Active, one Resetting). A trace showed exactly one auto-report call, coming from the round-end handler.
- **Round restart:** no report call, the respawn worked, and no new console errors appeared. The only errors are ones the scene already logs on load: no microphone on the cloud machine, plus DMGFX messages.
- **Screenshots:** 11, all passed the capture check. They only show the scene, since the change isn't visual.

**Still to check:**
- **One staging build:** confirm a report actually arrives after a Rumble round.
- **The playtest build's environment:** a build without the staging or development environment setting counts as production. It then sends no auto-reports in any mode, so this fix alone wouldn't bring reports back. I couldn't see how that build was made.

The PR description is in `_work/_temp/PullRequest.txt` and the result is in `junior-dev-result.json`.